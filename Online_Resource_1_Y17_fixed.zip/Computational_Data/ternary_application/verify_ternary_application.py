"""Exact arithmetic checks for the primitive equation X^3 = Y^17 + 2Z^17.

Uses only the Python standard library. Run with the bundled runtime; writes the
machine-readable result to verification_results.json beside this script.
"""

from fractions import Fraction
from itertools import product
import json
from pathlib import Path


def add(a, b):
    out = [Fraction(0)] * max(len(a), len(b))
    for i, x in enumerate(a):
        out[i] += Fraction(x)
    for i, x in enumerate(b):
        out[i] += Fraction(x)
    return trim(out)


def scale(c, a):
    return trim([Fraction(c) * Fraction(x) for x in a])


def mul(a, b):
    out = [Fraction(0)] * (len(a) + len(b) - 1)
    for i, x in enumerate(a):
        for j, y in enumerate(b):
            out[i + j] += Fraction(x) * Fraction(y)
    return trim(out)


def trim(a):
    out = list(a)
    while len(out) > 1 and out[-1] == 0:
        out.pop()
    return out


def power(a, n):
    out = [Fraction(1)]
    for _ in range(n):
        out = mul(out, a)
    return out


def show_poly(a):
    return [str(Fraction(x)) for x in trim(a)]


def mod_eval(coeffs, x, p):
    value = 0
    for c in reversed(coeffs):
        value = (value * x + c) % p
    return value


# Target polynomial: 27*s*(9*s-16)^3 - 8*j*(s-2), coefficients ascending.
s = [Fraction(0), Fraction(1)]
linear = [Fraction(-16), Fraction(9)]
target_base = scale(27, mul(s, power(linear, 3)))

cases = [
    {
        "j": Fraction(9261, 8),
        "factor": scale(
            27,
            mul(mul([Fraction(-1), Fraction(1)], [Fraction(-2), Fraction(9)]),
                [Fraction(343), Fraction(-333), Fraction(81)]),
        ),
    },
    {
        "j": Fraction(-132651, 2),
        "factor": scale(
            27,
            mul([Fraction(2), Fraction(1)],
                [Fraction(-19652), Fraction(17604), Fraction(-5346), Fraction(729)]),
        ),
    },
    {
        "j": Fraction(-1167051, 512),
        "factor": scale(
            Fraction(3, 64),
            mul([Fraction(1), Fraction(4)],
                [Fraction(-778034), Fraction(1141857), Fraction(-586116), Fraction(104976)]),
        ),
    },
]

factorization_results = []
for case in cases:
    # -8*j*(s-2) = 16*j - 8*j*s.
    target = add(target_base, [16 * case["j"], -8 * case["j"]])
    case["target"] = target
    case["identity"] = trim(target) == trim(case["factor"])
    factorization_results.append(
        {
            "j": str(case["j"]),
            "target_coefficients_ascending": show_poly(target),
            "factorized_coefficients_ascending": show_poly(case["factor"]),
            "identity_verified": case["identity"],
        }
    )

cubic_2 = [-19652, 17604, -5346, 729]
cubic_3 = [-778034, 1141857, -586116, 104976]
mod7_checks = []
for name, coeffs in (("second_factor_cubic", cubic_2), ("third_factor_cubic", cubic_3)):
    values = [mod_eval(coeffs, x, 7) for x in range(7)]
    roots = [x for x, value in enumerate(values) if value == 0]
    mod7_checks.append(
        {
            "polynomial": name,
            "values_at_0_through_6_mod_7": values,
            "roots_mod_7": roots,
            "rootless": not roots,
        }
    )


def count_points_and_invariants(X, Z):
    p = 5
    a1 = (3 * X) % p
    a3 = (2 * pow(Z, 17, p)) % p

    # For y^2 + a1*x*y + a3*y = x^3, the standard b-invariants simplify to:
    b2 = (a1 * a1) % p
    b4 = (a1 * a3) % p
    b6 = (a3 * a3) % p
    b8 = 0
    delta = (-b2 * b2 * b8 - 8 * b4**3 - 27 * b6 * b6 + 9 * b2 * b4 * b6) % p
    c4 = (b2 * b2 - 24 * b4) % p

    if delta == 0:
        return {"X": X, "Z": Z, "a1_mod5": a1, "a3_mod5": a3, "delta_mod5": 0, "excluded_singular": True}

    affine_points = 0
    for x, y in product(range(p), repeat=2):
        lhs = (y * y + a1 * x * y + a3 * y) % p
        rhs = pow(x, 3, p)
        affine_points += lhs == rhs
    point_count = affine_points + 1  # the point at infinity
    a5 = p + 1 - point_count
    j = (pow(c4, 3, p) * pow(delta, -1, p)) % p
    return {
        "X": X,
        "Z": Z,
        "a1_mod5": a1,
        "a3_mod5": a3,
        "delta_mod5": delta,
        "c4_mod5": c4,
        "affine_point_count": affine_points,
        "projective_point_count": point_count,
        "a5": a5,
        "j_mod5": j,
        "excluded_singular": False,
    }


all_models = [count_points_and_invariants(X, Z) for X in range(5) for Z in range(1, 5)]
singular_models = [row for row in all_models if row["excluded_singular"]]
nonsingular_models = [row for row in all_models if not row["excluded_singular"]]
a5_minus3 = [row for row in nonsingular_models if row["a5"] == -3]

assert all(case["identity"] for case in cases), "A claimed factorization failed."
assert all(item["rootless"] for item in mod7_checks), "A cubic has a root modulo 7."
assert len(all_models) == 20
assert len(nonsingular_models) + len(singular_models) == 20
assert all(row["j_mod5"] == 2 for row in a5_minus3), "Found a_5=-3 with j != 2."

result = {
    "arithmetic": "exact Fractions for polynomial identities; exhaustive arithmetic in F_5 and F_7",
    "factorizations": factorization_results,
    "mod_7_cubic_root_checks": mod7_checks,
    "frey_models_mod5": {
        "model": "y^2 + 3*X*x*y + 2*Z^17*y = x^3 over F_5",
        "enumerated_pairs": len(all_models),
        "singular_pairs_excluded_by_delta_zero": singular_models,
        "nonsingular_models": nonsingular_models,
        "a5_minus_3_models": a5_minus3,
        "implication_verified": "a5 = -3 implies j = 2 mod 5",
    },
}

out_path = Path(__file__).with_name("verification_results.json")
out_path.write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
print(json.dumps({
    "factorizations_verified": sum(case["identity"] for case in cases),
    "cubics_rootless_mod7": all(item["rootless"] for item in mod7_checks),
    "singular_pairs": [[row["X"], row["Z"]] for row in singular_models],
    "a5_minus3_pairs": [[row["X"], row["Z"]] for row in a5_minus3],
    "a5_minus3_all_j2": all(row["j_mod5"] == 2 for row in a5_minus3),
    "json": str(out_path),
}, indent=2))
