Finite checks for Sections 2 and 8

Run: python verify_ternary_application.py
Only the Python standard library is required.

The program checks the three polynomial identities over the rational numbers, both cubic reductions over F_7, and every Frey model over F_5 for X in F_5 and Z nonzero. The a_5=-3 pairs are (1,1), (2,3), (3,2), (4,4), and each has j=2. Results are written to verification_results.json.

The level-lowering argument and the rational-point denominator argument are given in the manuscript.
