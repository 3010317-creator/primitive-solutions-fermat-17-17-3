\\ Exact witness verifier/generator for 14 squareclasses of L(S,2).
\\ No bnf object or conditional class-group algorithms are called.
\\ Run from active_L18; global completeness uses the separate class-group theorem.
default(parisizemax,800000000);
run()={
  my(n=read("L18_nf_checkpoint.bin"),D=read("simon_descent/provisional_full2_matrix_data.bin"),G=D[1],F,pr,e,q,mp,v,R,M=matrix(0,14),W=List(),Facts=List(),T,rank0=0,done=0);
  if(nfcertify(n)!=[],error("Uncertified integral basis"));
  if(#G!=14 || n.sign!=[2,8],error("Incorrect dimensions"));
  print("FIELD_DEGREE=",poldegree(n.pol));
  print("FIELD_SIGNATURE=",n.sign);
  print("INTEGRAL_BASIS_UNCONDITIONALLY_CERTIFIED=1");
  print("S_DECOMPOSITION=",[vector(#idealprimedec(n,2),i,[idealprimedec(n,2)[i].e,idealprimedec(n,2)[i].f]),vector(#idealprimedec(n,17),i,[idealprimedec(n,17)[i].e,idealprimedec(n,17)[i].f])]);
  for(i=1,14,
    F=idealfactor(n,G[i]);
    T=matid(18);
    for(j=1,matsize(F)[1],
      pr=F[j,1]; e=F[j,2];
      if(pr.p!=2 && pr.p!=17 && e%2,error("Odd valuation outside S"));
      T=idealmul(n,T,idealpow(n,pr,e));
    );
    if(idealhnf(n,T)!=idealhnf(n,G[i]),error("Principal ideal factorization mismatch"));
    if(i<=10 && idealhnf(n,G[i])!=matid(18),error("Expected unit is not a unit"));
    listput(Facts,F);
    print("GENERATOR_",i,"_FACTORIZATION_SUMMARY=",vector(matsize(F)[1],j,[F[j,1].p,F[j,1].e,F[j,1].f,F[j,2]]));
  );
  print("ALL_14_GENERATORS_HAVE_EVEN_VALUATIONS_OUTSIDE_S=1");
  forprime(q=3,100000,
    if(q==17 || q==719,next);
    for(k=1,#idealprimedec(n,q,1),
      pr=idealprimedec(n,q,1)[k]; mp=nfmodprinit(n,pr);
      R=vector(14,j,
        v=nfmodpr(n,G[j],mp)^((q-1)/2);
        if(v==0,error("Character not defined at nonunit"));
        if(v!=1 && v!=-1,error("Invalid quadratic character"));
        if(v==1,0,1)
      );
      if(matrank(Mod(matconcat([M;Mat(R)]),2))>rank0,
        M=matconcat([M;Mat(R)]);rank0++;
        listput(W,[q,pr[2],R]);
        print("NEW_INDEPENDENT_CHARACTER=",[rank0,q,pr[2],R]);
      );
      if(rank0==14,done=1;break);
    );
    if(done,break);
  );
  if(rank0!=14,error("Could not certify 14 independent squareclasses"));
  if(matsize(M)!=[14,14] || lift(matdet(Mod(M,2)))!=1,error("Character matrix singular"));
  print("CHARACTER_MATRIX=",M);
  print("CHARACTER_MATRIX_DETERMINANT_MOD2=1");
  print("GLOBAL_SQUARECLASS_INDEPENDENCE_UNCONDITIONAL=14");
  print("COMPLETENESS_CONDITIONAL_ON_CLASS_GROUP_THEOREM=1");
  writebin("../direct_descent/L18_S2_basis_witness.bin",[n.pol,n.zk,G,Vec(Facts),Vec(W),M]);
};
iferr(run(),err,print("S2_BASIS_VERIFICATION_FAILED=",err);quit(1));
quit;
