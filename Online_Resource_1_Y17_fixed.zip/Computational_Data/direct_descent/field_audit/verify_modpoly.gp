default(nbthreads,1);default(parisizemax,1600000000);
read("../direct_descent/field_audit/exact_inputs.gp");
run()={
 my(P=0,C,New);
 for(k=1,#PhiCoeffs,C=PhiCoeffs[k];P+=C[3]*x^C[1]*y^C[2];if(C[1]!=C[2],P+=C[3]*x^C[2]*y^C[1]));
 print("BEGIN_PARI_MODULAR_POLYNOMIAL_RECONSTRUCTION");
 New=polmodular(17,0,x,y);
 if(P!=New,error("Independent modular polynomial mismatch"));
 print("PARI_POLMODULAR17_MATCHES_ALL172_STORED_COEFFICIENT_ROWS=1");
 writebin("../direct_descent/field_audit/phi17_independent.bin",New);
};
iferr(run(),e,print("MODPOLY_AUDIT_FAILED=",e);quit(1));quit;
