#!/usr/bin/env python3
"""Exact q-expansion certificate for the classical modular polynomial Phi_17.
No modular-polynomial database or PARI construction is used in this verifier.

On X_0(17), j(z), j(17z) have only the two cusp poles; candidate pole order
at each cusp <=306. Vanishing through q^306 at infinity forces identity:
a nonzero modular function cannot have a zero of order >=307 and its sole
remaining pole of order <=306. Computation uses integral power series.
"""
from pathlib import Path
import re,json,hashlib,time
from flint import fmpz_poly as ZP
SRC=Path('/workspace/scratch/4094a4d93451/active_L18/phi_j_17.txt')
OUT=Path(__file__).resolve().parent
rows=[tuple(map(int,m)) for m in re.findall(r'\[(\d+),(\d+)\]\s+(-?\d+)',SRC.read_text())]
terms=[]
for i,j,c in rows:
    terms.append((i,j,c))
    if i!=j:terms.append((j,i,c))
assert [(i,j,c) for i,j,c in terms if i==18]==[(18,0,1)]
assert [(i,j,c) for i,j,c in terms if j==18]==[(0,18,1)]
Npole=max(i+17*j for i,j,c in terms)
assert Npole==max(17*i+j for i,j,c in terms)==306
order=2*Npole+1 # check q^306 Phi(...), coefficients0..612.
# Need E4^3 and Delta through q^(order) to compute q*j through q^(order-1).
N=order+1
sig3=[0]*N;sig5=[0]*N
for d in range(1,N):
    a=d**3;b=d**5
    for n in range(d,N,d):sig3[n]+=a;sig5[n]+=b
E4=ZP([1]+[240*sig3[n] for n in range(1,N)])
E6=ZP([1]+[-504*sig5[n] for n in range(1,N)])
A=E4.pow_trunc(3,N)
Dnum=(A-E6.pow_trunc(2,N)).truncate(N)
assert all(int(c)%1728==0 for c in Dnum.coeffs())
Delta=[int(Dnum[n])//1728 for n in range(N)]
assert Delta[0]==0 and Delta[1]==1
# (q*j)*(Delta/q)=E4^3, exact coefficient recursion.
js=[0]*order
for n in range(order):
    js[n]=int(A[n])-sum(Delta[k+1]*js[n-k] for k in range(1,n+1))
assert js[:6]==[1,744,196884,21493760,864299970,20245856256]
J=ZP(js)
K=ZP([js[n//17] if n%17==0 else 0 for n in range(order)])
pJ=[ZP([1])];pK=[ZP([1])]
for i in range(1,19):
    pJ.append((pJ[-1]*J).truncate(order))
    pK.append((pK[-1]*K).truncate(order))
res=ZP([])
for i,j,c in terms:
    sh=Npole-i-17*j
    assert sh>=0
    v=(pJ[i]*pK[j]).truncate(order-sh)
    if sh:v=ZP([0]*sh+[int(a) for a in v.coeffs()])
    res=(res+c*v).truncate(order)
assert not res
report={
 'method':'Integral Eisenstein series E4,E6 and Delta=(E4^3-E6^2)/1728; exact q-series division',
 'stored_symmetric_rows':len(rows),'full_monomials':len(terms),
 'maximum_pole_order_at_each_cusp':Npole,
 'tested_coefficients_of_Phi_in_q':[-Npole,Npole],
 'all_tested_coefficients_are_zero':True,
 'resulting_zero_order_at_infinity_at_least':Npole+1,
 'j_series_first_coefficients':js[:12],
 'polynomial_source_sha256':hashlib.sha256(SRC.read_bytes()).hexdigest(),
 'proof':'The sole other cusp pole has order at most306; zero order at infinity at least307 forces the modular function to be identically zero. Monic degree18 and index[SL2(Z):Gamma0(17)]=18 identify the classical modular polynomial.'}
(OUT/'phi17_qexp_certificate.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report,indent=2))
