default(nbthreads,1);default(parisizemax,2000000000);
read("../direct_descent/field_audit/exact_inputs.gp");
run()={
 my(v=varhigher("v"),Rel=v^2+(x+1)*v-(x^3-x^2-x-14),V=Mod(v,Rel),lam,nu,Xw,Yw,J1,J2,J2num,c,d,den=x-7,P1,P2,Pow1,Pow2,Sum=0,C,ex,Nclear);
 if(13^2+7*13+13!=7^3-7^2-7-14,error("T not on curve"));
 lam=(V+x+14)/(7-x);nu=13-7*lam;
 Xw=lam^2+lam-x-6;Yw=-(lam+1)*Xw-nu-1;
 if(Yw^2+(Xw+1)*Yw!=Xw^3-Xw^2-Xw-14,error("Fricke candidate not on curve"));
 print("T_MINUS_P_EXACT_CURVE_MAP_VERIFIED=1");
 J1=(jA+jB*V)/den^17;
 print("BEGIN_EXACT_FRICKE_J_SUBSTITUTION");
 J2=(subst(jA,x,Xw)+subst(jB,x,Xw)*Yw)/(Xw-7)^17;
 J2num=lift(J2*den);c=polcoef(J2num,0,v);d=polcoef(J2num,1,v);
 if(type(c)!="t_POL" || type(d)!="t_POL",error("Unexpected denominators in transformed j numerator"));
 if(poldegree(c)>9 || poldegree(d)>8,error("Unexpected Fricke numerator degree"));
 print("FRICKE_J_NUMERATOR_DEGREES=",[poldegree(c),poldegree(d)]);
 write("../direct_descent/field_audit/fricke_j_numerator.txt","C=",c,";D=",d,";");
 print("BEGIN_DENOMINATOR_CLEARED_MODULAR_IDENTITY");
 P1=jA+jB*V;P2=c+d*V;
 Pow1=vector(19,i,P1^(i-1));Pow2=vector(19,i,P2^(i-1));
 Nclear=vecmax(vector(#PhiCoeffs,k,max(17*PhiCoeffs[k][1]+PhiCoeffs[k][2],17*PhiCoeffs[k][2]+PhiCoeffs[k][1])));
 print("COMMON_DENOMINATOR_EXPONENT=",Nclear);
 for(k=1,#PhiCoeffs,
   C=PhiCoeffs[k];ex=Nclear-17*C[1]-C[2];
   Sum+=C[3]*Pow1[C[1]+1]*Pow2[C[2]+1]*den^ex;
   if(C[1]!=C[2],ex=Nclear-17*C[2]-C[1];Sum+=C[3]*Pow1[C[2]+1]*Pow2[C[1]+1]*den^ex);
 );
 if(Sum!=0,error("Phi17(j(P),j(T-P)) is nonzero"));
 print("PHI17_J_P_J_T_MINUS_P_EXACT_IDENTITY=1");
 \\ Pole degree: at infinity numerator has pole35 and denominator34 -> pole1.
 \\ At T=(7,13), denominator order17 and numerator nonzero -> pole17.
 \\ At -T=(7,-21), elimination identity cancels exactly all17 denominator orders.
 if(poldegree(jA)!=17 || poldegree(jB)!=16 || pollead(jB)!=1,error("Infinity pole order calculation mismatch"));
 if(subst(jA,x,7)+13*subst(jB,x,7)==0,error("No order17 pole at T"));
 my(Nnorm=jA^2-(x+1)*jA*jB-(x^3-x^2-x-14)*jB^2,Nother=subst(jA,x,7)+13*subst(jB,x,7));
 if(valuation(Nnorm,x-7)!=17,error("Cancellation at -T has wrong order"));
 print("J_MAP_POLE_ORDERS_AT_O_AND_T=[1,17]");
 print("J_MAP_DEGREE18_CERTIFIED=1");
 writebin("../direct_descent/field_audit/jmap_fricke_witness.bin",[jA,jB,c,d,Nnorm,Nclear]);
 print("J_MAP_MODULAR_IDENTIFICATION_AUDIT_PASSED=1");
};
iferr(run(),e,print("JMAP_AUDIT_FAILED=",e);quit(1));quit;
