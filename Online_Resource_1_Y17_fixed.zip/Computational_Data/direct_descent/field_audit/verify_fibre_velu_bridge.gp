default(nbthreads,1);default(parisizemax,1000000000);
read("../direct_descent/field_audit/exact_inputs.gp");
run()={
 my(W=read("../direct_descent/field_audit/fresh_field_witness.bin"),J=read("../direct_descent/field_audit/jmap_fricke_witness.bin"),alpha=W[3],Pt=W[6],Jv,Jw,E);
 Jv=subst(qJ,y,alpha);
 Jw=(subst(J[3],x,Pt[1])+subst(J[4],x,Pt[1])*Pt[2])/(Pt[1]-7);
 if(Jv!=Jw,error("Velu quotient j and Fricke j at P1 differ"));
 if(poldegree(minpoly(Jv))!=18,error("Quotient j does not generate degree18 field"));
 print("VELU_QUOTIENT_J_EQUALS_FRICKE_J_AT_P1_EXACTLY=1");
 print("QUOTIENT_J_GENERATES_CYCLIC17_SUBGROUP_FIELD=1");
 my(u=varhigher("u"),v=varhigher("v"),rel=v^2+3*u*v+2*v-u^3,XX=4*u+3,YY=8*v+12*u+8);
 if((YY^2-XX^3-21*XX+26)%rel!=0,error("Frey to short source isomorphism failed"));
 print("FREY_AT_X1_TO_SHORT_SOURCE_CURVE_EXACT_ISOMORPHISM=1");
 writebin("../direct_descent/field_audit/fibre_velu_bridge.bin",[alpha,Pt,Jv,Jw]);
};
iferr(run(),e,print("FIBRE_VELU_BRIDGE_FAILED=",e);quit(1));quit;
