default(nbthreads,1);default(parisizemax,1600000000);
read("../direct_descent/field_audit/exact_inputs.gp");
run()={
 my(E=ellinit([0,0,0,21,-26]),Psi=elldivpol(E,17,x),S=0,S2=0,S3=0,Xk,nd,s,Aq,Bq,Jq,rr=0,C);
 Psi=Psi/pollead(Psi);
 if(Psi!=StoredPsi,error("Independent psi17 mismatch"));
 for(k=1,8,
   nd=ellxn(E,k,x);
   if(poldegree(gcd(nd[2],Psi))!=0,error("Multiplication map has pole on17-torsion"));
   Xk=Mod(nd[1],Psi)/Mod(nd[2],Psi);
   S+=Xk;S2+=Xk^2;S3+=Xk^3;
   print("INDEPENDENT_MULTIPLICATION_MAP_ADDED=",k);
 );
 if(S!=Mod(StoredS,Psi),error("Kernel trace differs from original certificate"));
 s=S/4;
 if(subst(Fsmall,y,s)!=0,error("Degree18 resolvent does not annihilate trace"));
 if(!polisirreducible(Mod(Fsmall,5)),error("Resolvent irreducibility failed"));
 print("KERNEL_SUM_FROM_PARI_ELLXN_MATCHES_ORIGINAL_EXACTLY=1");
 print("DEGREE18_IRREDUCIBLE_POLYNOMIAL_ANNIHILATES_KERNEL_TRACE=1");
 if(subst(qS2,y,s)!=S2 || subst(qS3,y,s)!=S3,error("Trace power sum embedding failed"));
 print("S2_AND_S3_EMBEDDINGS_EXACTLY_VERIFIED=1");
 Aq=-79*21-30*S2;Bq=-223*(-26)-42*21*S-70*S3;
 if(subst(qA,y,s)!=Aq || subst(qB,y,s)!=Bq,error("Velu coefficients mismatch"));
 if(4*Aq^3+27*Bq^2==0,error("Singular quotient curve"));
 Jq=6912*Aq^3/(4*Aq^3+27*Bq^2);
 if(subst(qJ,y,s)!=Jq,error("Stored quotient j does not match Velu"));
 print("VELU_QUOTIENT_A_B_J_EXACTLY_VERIFIED=1");
 \\ Check in the degree18 algebra rather than the degree144 algebra.
 my(jj=Mod(qJ,Fsmall));
 for(k=1,#PhiCoeffs,
   C=PhiCoeffs[k];rr+=C[3]*(9261/8)^C[1]*jj^C[2];
   if(C[1]!=C[2],rr+=C[3]*(9261/8)^C[2]*jj^C[1]);
 );
 if(rr!=0,error("Phi17(source j,quotient j) nonzero"));
 print("MODULAR_POLYNOMIAL_VELU_RELATION_EXACTLY_VERIFIED=1");
 writebin("../direct_descent/field_audit/kernel_velu_witness.bin",[Psi,S,S2,S3,Aq,Bq,Jq]);
 print("KERNEL_RESOLVENT_AND_VELU_AUDIT_PASSED=1");
};
iferr(run(),e,print("KERNEL_AUDIT_FAILED=",e);quit(1));quit;
