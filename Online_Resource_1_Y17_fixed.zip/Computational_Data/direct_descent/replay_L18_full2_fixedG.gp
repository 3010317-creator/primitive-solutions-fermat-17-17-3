\\ Rebuild all local Kummer images and constraints from the fixed, certified G.
\\ All previous output files are read-only comparison targets. No bnf routines.
default(nbthreads,1);
default(parisizemax,1200000000);
read("simon_descent/X017_full2_local2.gp");
read("X017_local17_full2.gp");
interval_poly(f,a,b)={
 my(lo=0,hi=0,z);
 forstep(k=poldegree(f),0,-1,
   z=[lo*a,lo*b,hi*a,hi*b];
   lo=vecmin(z)+polcoef(f,k);hi=vecmax(z)+polcoef(f,k);
 );return([lo,hi]);
};
run()={
 my(N=read("L18_nf_checkpoint.bin"),Old=read("simon_descent/provisional_full2_matrix_data.bin"),G=Old[1],ng=#G,L2,Ps,D,Img,r,V,H,C17,I17,p17,All=matrix(0,28),Opp=matrix(0,14),Ip,Op17,V17,NewK,OldK,Diag,Dk,AA,CharData,W,CharM,chars,coords,sq,Q,AC=matrix(14,11),Witness=List(),Signs=matrix(2,14),Bounds=[[2258/1000,2259/1000],[2310/1000,2311/1000]],a,b,mid,intv,allok);
 if(ng!=14 || nfcertify(N)!=[],error("Field or global input mismatch"));
 Ps=idealprimedec(N,2);if(#Ps!=2,error("Dyadic prime count"));
 L2=vector(2,k,x017_local2_fullimage(N,Ps[k]));
 for(k=1,2,
   D=L2[k][1];Img=L2[k][2];r=matsize(Img)[1]/2;
   if(matrank(Mod(Img,2))!=if(k==1,19,3),error("Unexpected dyadic image rank"));
   V=matrix(2*r,28);
   for(j=1,14,
     my(v=x017_local2_squareclass(N,D,G[j]));
     for(i=1,r,V[i,j]=v[i];V[r+i,14+j]=v[i]);
   );
   H=matker(Mod(Img~,2))~;
   All=matconcat([All;lift(H*Mod(V,2))]);
   print("REBUILT_DYADIC_CONSTRAINTS=",[k,matrank(Mod(All,2)),28-matrank(Mod(All,2))]);
   Ip=Img[1..r,]+Img[r+1..2*r,];
   Opp=matconcat([Opp;lift(matker(Mod(Ip~,2))~*Mod(V[1..r,1..14],2))]);
   print("REBUILT_OPPOSITE_DYADIC_IMAGE_DIM=",[k,matrank(Mod(Ip,2))]);
 );
 p17=idealprimedec(N,17)[1];I17=x017_local17_image(N)~;
 if(matrank(Mod(I17,2))!=2,error("Local17 image rank"));
 print("REBUILT_17_IMAGE_RANK=2");
 C17=matrix(4,28);
 for(j=1,14,
   my(v=x017_local17_squareclass(N,p17,G[j]));
   C17[1,j]=v[1];C17[2,j]=v[2];C17[3,14+j]=v[1];C17[4,14+j]=v[2];
 );
 All=matconcat([All;lift(matker(Mod(I17~,2))~*Mod(C17,2))]);
 Op17=I17[1..2,]+I17[3..4,];
 if(matrank(Mod(Op17,2))<2,Opp=matconcat([Opp;lift(matker(Mod(Op17~,2))~*Mod(C17[1..2,1..14],2))]));
 print("REBUILT_FINITE_CONSTRAINT_RANK=",matrank(Mod(All,2)));
 \\ Exact real signs via rational intervals and Sturm root isolation.
 if(polsturm(N.pol)!=2,error("Not exactly two real roots"));
 for(i=1,2,
   a=Bounds[i][1];b=Bounds[i][2];
   if(polsturm(N.pol,[a,b])!=1,error("Real root isolating interval failed"));
   allok=0;
   for(step=0,256,
     allok=1;
     for(j=1,14,
       intv=interval_poly(lift(G[j]),a,b);
       if(intv[1]>0,Signs[i,j]=0,if(intv[2]<0,Signs[i,j]=1,allok=0));
     );
     if(allok,break);
     mid=(a+b)/2;
     if(polsturm(N.pol,[a,mid])==1,b=mid,a=mid);
   );
   if(!allok,error("Could not certify all real signs"));
   Bounds[i]=[a,b];
   if(polsturm(N.pol,Bounds[i])!=1,error("Final real root isolation failure"));
   for(j=1,14,if(Signs[i,j]!=(1-nfeltsign(N,G[j],i))/2,error("Exact and nf real signs disagree")));
   print("EXACT_REAL_SIGN_ROW=",[i,Signs[i,]]);
 );
 All=matconcat([All;concat(Signs,Signs)]);Opp=matconcat([Opp;Signs]);
 NewK=lift(matker(Mod(All,2)));OldK=Old[3];
 if(matsize(NewK)!=[28,13],error("Full2 dimension is not13"));
 if(matrank(Mod(concat(NewK,OldK),2))!=13,error("Full2 kernel differs from frozen data"));
 if(matrank(Mod(matconcat([All;Old[2]]),2))!=15,error("Full2 constraint rowspaces differ"));
 print("FULL2_CONSTRAINT_MATRIX_EQUAL=",All==Old[2]);
 print("FULL2_CONSTRAINT_ROWSPACE_EQUAL=1");
 print("FULL2_KERNEL_SPACE_EQUAL=1");
 print("FULL2_SELMER_DIMENSION_WITH_COMPLETE_GLOBAL_INPUT=13");
 Diag=All[,1..14]+All[,15..28];Dk=lift(matker(Mod(Diag,2)));
 if(matsize(Dk)[2]!=11,error("Diagonal dimension is not11"));
 print("DIAGONAL_INITIAL_ISOGENY_SELMER_DIMENSION=11");
 \\ Identify the exact stored diagonal representatives using independent characters.
 CharData=read("../direct_descent/L18_S2_basis_witness.bin");
 if(CharData[1]!=N.pol || CharData[3]!=G,error("Character certificate does not match G"));
 W=CharData[5];CharM=CharData[6];AA=read("simon_descent/provisional_diagonal11.bin");
 if(#AA!=11,error("Stored diagonal generator count"));
 for(j=1,11,
   chars=vector(14,k,
     my(q=W[k][1],dec=idealprimedec(N,q,1),pr=0,im);
     for(z=1,#dec,if(dec[z][2]==W[k][2],pr=dec[z];break));
     if(pr==0,error("Character prime not found"));
     im=nfmodpr(N,AA[j],pr)^((q-1)/2);
     if(im!=1 && im!=-1,error("Undefined diagonal character"));
     if(im==1,0,1)
   )~;
   coords=lift(matsolve(Mod(CharM,2),Mod(chars,2)));AC[,j]=coords;
   Q=AA[j]/prod(i=1,14,G[i]^coords[i]);
   if(!nfeltissquare(N,Q,&sq),error("Diagonal representative not in G span"));
   sq=nfbasistoalg(N,sq);if(sq^2!=Q,error("Exact diagonal square witness failed"));
   if(Mod(Diag,2)*Mod(coords,2)!=vector(matsize(Diag)[1],i,Mod(0,2))~,error("Diagonal class fails local condition"));
   listput(Witness,[coords,sq]);
 );
 if(matrank(Mod(AC,2))!=11,error("Stored diagonal classes dependent"));
 if(matrank(Mod(concat(Dk,AC),2))!=11,error("Stored diagonal classes not complete"));
 print("STORED_DIAGONAL11_EXACTLY_SPANS_REBUILT_DIAGONAL_SPACE=1");
 my(Ok=lift(matker(Mod(Opp,2))));
 if(matsize(Ok)[2]!=2,error("Opposite initial dimension is not2"));
 print("REBUILT_OPPOSITE_INITIAL_DIMENSION=2");
 writebin("../direct_descent/L18_full2_fixedG_replay.bin",[G,All,NewK,L2,I17,Signs,Bounds,Diag,Dk,AA,AC,Vec(Witness),Opp,Ok]);
 print("FIXED_G_LOCAL_SELMER_REPLAY_PASSED=1");
 print("NO_BNF_OR_CONDITIONAL_FUNDAMENTAL_UNIT_COMPUTATION_USED=1");
};
iferr(run(),err,print("FIXED_G_LOCAL_SELMER_REPLAY_FAILED=",err);quit(1));
quit;
