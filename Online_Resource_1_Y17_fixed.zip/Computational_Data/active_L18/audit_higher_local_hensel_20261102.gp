default(nbthreads,1);
default(parisizemax,1200000000);
allocatemem(134217728);
{
N=read("L18_nf_checkpoint.bin");
H=read("simon_descent/Cassels_higher_lowdisc_second_lift.bin");
EM=H[12];
Dy=read("simon_descent/Cassels_higher_lowdisc_E_local2_points.bin");
D17=read("simon_descent/Cassels_higher_lowdisc_E_local17_point.bin");
Push=read("simon_descent/Cassels_higher_lowdisc_pushout_data.bin")[1];
for(k=1,3,
 if(k<=2,p=Dy[k][1];P=Dy[k][4],p=D17[1];P=D17[2]);
 pi=nfbasistoalg(N,p[2]);if(nfeltval(N,pi,p)!=1,error("Nonuniformizer"));
 Z=vector(4,j,P[j][1])~;
 vmin=vecmin(vector(4,j,if(Z[j]==0,10^8,nfeltval(N,Z[j],p))));
 Z*=pi^(-vmin);
 for(i=1,2,for(j=1,4,for(l=1,4,if(EM[i][j,l] && nfeltval(N,EM[i][j,l],p)<0,error("Nonintegral quadric coefficient")))));
 F=vector(2,i,Z~*EM[i]*Z);
 m=vecmin(vector(2,i,if(F[i]==0,10^8,nfeltval(N,F[i],p))));
 Jac=matrix(2,4,i,j,(2*EM[i]*Z)[j]);
 best=10^8;cols=[0,0];
 for(i=1,4,for(j=i+1,4,
  d=Jac[1,i]*Jac[2,j]-Jac[1,j]*Jac[2,i];
  if(d && nfeltval(N,d,p)<best,best=nfeltval(N,d,p);cols=[i,j]);
 ));
 if(m<=2*best,error("Multivariate Hensel criterion failed"));
 acc=m-best;if(acc<=0,error("Root accuracy nonpositive"));
 if(k<=2,
  FF=Push[6];valF=nfeltval(N,Z~*FF*Z,p);
  contval=vecmin(concat(vector(4,i,vector(4,j,if(FF[i,j]==0,10^8,nfeltval(N,FF[i,j],p))))));
  margin=acc+contval-valF-2*p[3];
  if(margin<=0,error("Root correction may change pushout squareclass"));
  print("HIGHER_DIRECT_HENSEL_AND_PUSHOUT=",[k,p[1],p[3],vmin,cols,m,best,acc,contval,valF,margin]);
 ,
  print("HIGHER_DIRECT_HENSEL_AT17=",[k,p[1],p[3],vmin,cols,m,best,acc]);
 );
);
print("HIGHER_LOCAL_EXISTENCE_INDEPENDENT_HENSEL_AUDIT_OK");
}
quit;
