\\ Fresh exact prime-ideal norm data for the unconditional BDF Corollary 5.2.
\\ Run from a fresh output directory; this writes only prime_norms_50000.json.
default(nbthreads,1);
default(parisizemax,1000000000);
run()={
 my(g=y^18-6*y^17+136*y^15-612*y^14-3060*y^13+46444*y^12-208998*y^11+417996*y^10-376278*y^9+1701258*y^8-12150648*y^7+41782464*y^6-84353490*y^5+109537290*y^4-93550626*y^3+51213384*y^2-16413030*y+2359296,n,rows=List(),total=0,np=0);
 if(!polisirreducible(g),error("Polynomial is reducible"));
 n=nfinit(g);
 if(nfcertify(n)!=[],error("Maximal-order certification failed"));
 if(n.sign!=[2,8],error("Incorrect signature"));
 if(n.disc!=2^16*3^20*17^17,error("Incorrect discriminant"));
 forprime(p=2,50000,
  my(ps=idealprimedec(n,p),counts=vector(18),ef=0);
  np++;
  for(j=1,#ps,
   my(f=ps[j].f,e=ps[j].e,q=idealnorm(n,ps[j]));
   if(q!=p^f,error("Prime norm mismatch"));
   ef+=e*f;
   if(q<=50000,counts[f]++;total++);
  );
  if(ef!=18,error("Incomplete decomposition"));
  for(f=1,18,if(counts[f],listput(rows,[p,f,counts[f]])));
 );
 write("prime_norms_50000.json",Vec(rows));
 print("EXACT_PRIME_IDEAL_NORMS_REBUILT_FROM_FRESH_NFINIT=1");
 print("RATIONAL_PRIMES=",np);
 print("PRIME_IDEALS_NORM_LE_50000=",total);
 print("NORM_MULTIPLICITY_ROWS=",#rows);
};
iferr(run(),E,print("PRIME_NORM_EXPORT_FAILED ",E);quit(1));
quit;
