default(nbthreads,1);
default(parisizemax,500000000);
install("x17_certify_expanded_interval","GGGGGG","range_check","/workspace/scratch/4094a4d93451/reproduction_test/final_small_bound_full_class/runtime/optimized_prime_certifier.so");
run_range()={
 my(b=read("/workspace/scratch/4094a4d93451/active_L18/L18_bnf_checkpoint.bin"),V,v);
 if(b.cyc!=[16] || nfcertify(b.nf)!=[],error("Uncertified field or incorrect candidate"));
 V=read("/workspace/scratch/4094a4d93451/active_L18/class_certification/factor_base_50000.bin");
 gettime();v=range_check(b,4000002,4500001,10000000,.9,V);
 print("REPRODUCE_CLASS_RANGE_PASS 4000002 4500001 ",gettime()," ",v);
};
iferr(run_range(),E,print("REPRODUCE_CLASS_RANGE_FAILED ",E);quit(1));
quit;
