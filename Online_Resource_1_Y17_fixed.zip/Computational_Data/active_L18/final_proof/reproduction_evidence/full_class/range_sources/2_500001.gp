default(nbthreads,1);
default(parisizemax,1200000000);
install("audit_certify_fullprime_range","GGGG","range_check","/workspace/scratch/4094a4d93451/reproduction_test/final_small_bound_full_class/runtime/strict_prefix_certifier.so");
run_range()={
 my(b=read("/workspace/scratch/4094a4d93451/active_L18/L18_bnf_checkpoint.bin"),V,v);
 if(b.cyc!=[16] || nfcertify(b.nf)!=[],error("Uncertified field or incorrect candidate"));
 
 gettime();v=range_check(b,2,500001,10000000);
 print("REPRODUCE_CLASS_RANGE_PASS 2 500001 ",gettime()," ",v);
};
iferr(run_range(),E,print("REPRODUCE_CLASS_RANGE_FAILED ",E);quit(1));
quit;
