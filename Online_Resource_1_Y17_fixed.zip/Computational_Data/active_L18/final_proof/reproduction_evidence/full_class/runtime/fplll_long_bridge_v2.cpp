// Isolated candidate-basis accelerator.  It does not certify class groups.
// Built against the official fplll 5.5.0 headers and the fpylll 0.6.4 wheel.
#include <fplll/gso.h>
#include <fplll/lll.h>

#include <cmath>
#include <cstdint>
#include <limits>
#include <array>
#include <algorithm>

namespace {
constexpr int dim = 18;
constexpr std::uint64_t default_budget = 100000;
using Z = fplll::Z_NR<long>;
using F = fplll::FP_NR<double>;
using Matrix = fplll::ZZ_mat<long>;
using BaseGSO = fplll::MatGSO<Z, F>;

// Codes are returned unchanged through the C boundary.
struct Rejected { int code; };

class GuardedGSO final : public BaseGSO {
  std::uint64_t budget_;
  std::uint64_t &used_;
  std::array<std::uint64_t, dim> basis_max_, transform_max_;

  void tick() {
    if (++used_ > budget_) throw Rejected{6};
  }

  static std::uint64_t row_max(const fplll::Matrix<Z> &m, int i) {
    std::uint64_t maximum = 0;
    for (int k = 0; k < dim; ++k) {
      const long value = m[i][k].get_si();
      maximum = std::max(maximum, static_cast<std::uint64_t>(value < 0 ? -value : value));
    }
    return maximum;
  }

  void check_rows(int i, int j, long multiplier) {
    const std::uint64_t coeff = multiplier < 0 ? -multiplier : multiplier;
    constexpr auto limit = std::numeric_limits<long>::max();
    if (static_cast<unsigned __int128>(coeff)*basis_max_[j]+basis_max_[i] > limit ||
        static_cast<unsigned __int128>(coeff)*transform_max_[j]+transform_max_[i] > limit)
      throw Rejected{4};
  }

  void refresh(int i) {
    basis_max_[i] = row_max(b, i);
    transform_max_[i] = row_max(u, i);
  }

public:
  GuardedGSO(Matrix &basis, Matrix &transform, Matrix &inverse,
             std::uint64_t budget, std::uint64_t &used)
      : BaseGSO(basis, transform, inverse, 0), budget_(budget), used_(used) {
    for (int i = 0; i < dim; ++i) refresh(i);
  }

  void row_addmul_we(int i, int j, const F &x, long expo_add) override {
    tick();
    const double raw = x.get_d();
    if (!std::isfinite(raw)) throw Rejected{5};
    // Default GSO has no row exponents.  This conservative guard also covers
    // any future invocation with exponents, without invoking a long shift.
    if (expo_add < -1024 || expo_add > 1024) throw Rejected{4};
    const double scaled = std::ldexp(raw, static_cast<int>(expo_add));
    constexpr double limit = 9223372036854775808.0; // exactly 2^63
    if (!std::isfinite(scaled) || scaled <= -limit || scaled >= limit)
      throw Rejected{4};
    long expo = 0;
    const long multiplier = x.get_si_exp_we(expo, expo_add);
    if (expo != 0) throw Rejected{4};
    check_rows(i, j, multiplier);
    if (multiplier == 1) BaseGSO::row_add(i, j);
    else if (multiplier == -1) BaseGSO::row_sub(i, j);
    else if (multiplier != 0) BaseGSO::row_addmul_we(i, j, x, expo_add);
    refresh(i);
  }

  void row_add(int i, int j) override {
    tick();
    check_rows(i, j, 1);
    BaseGSO::row_add(i, j);
    refresh(i);
  }
  void row_sub(int i, int j) override {
    tick();
    check_rows(i, j, -1);
    BaseGSO::row_sub(i, j);
    refresh(i);
  }
  void move_row(int old_row, int new_row) override {
    tick();
    BaseGSO::move_row(old_row, new_row);
    for (auto *bounds : {&basis_max_, &transform_max_}) {
      if (new_row < old_row)
        std::rotate(bounds->begin()+new_row, bounds->begin()+old_row,
                    bounds->begin()+old_row+1);
      else if (new_row > old_row)
        std::rotate(bounds->begin()+old_row, bounds->begin()+old_row+1,
                    bounds->begin()+new_row+1);
    }
  }
  void row_swap(int i, int j) override {
    tick();
    BaseGSO::row_swap(i, j);
    std::swap(basis_max_[i], basis_max_[j]);
    std::swap(transform_max_[i], transform_max_[j]);
  }
  void negate_row_of_b(int i) override {
    tick();
    BaseGSO::negate_row_of_b(i);
  }
  F &get_gram(F &f, int i, int j) override {
    tick();
    return BaseGSO::get_gram(f, i, j);
  }
};
} // namespace

#define EXPORT extern "C" __attribute__((visibility("default")))

// Row-major input and output, each of length 18*18.  On success T*input is
// the basis produced by direct long/double GSO LLL.  Outputs are only written
// on success.  A nonzero status means the caller should use its fallback.
// 1: null argument, 2: ABI/input range, 3: LLL numeric failure,
// 4: integer overflow risk, 5: nonfinite numeric value, 6: operation budget,
// 7: allocation/library exception.
EXPORT int fplll_long18_transform_ex(const std::int64_t *input,
                                    std::int64_t *transform,
                                    std::int64_t *reduced_basis,
                                    std::uint64_t operation_budget,
                                    std::uint64_t *operations_used) noexcept {
  std::uint64_t used = 0;
  if (operations_used) *operations_used = 0;
  if (!input || !transform) return 1;
  if (sizeof(long) != sizeof(std::int64_t)) return 2;
  try {
    Matrix basis(dim, dim), trans(dim, dim), inverse;
    trans.gen_identity(dim);
    for (int i = 0; i < dim; ++i)
      for (int j = 0; j < dim; ++j) {
        const auto value = input[i * dim + j];
        if (value == std::numeric_limits<std::int64_t>::min()) return 2;
        basis[i][j] = static_cast<long>(value);
      }
    GuardedGSO gso(basis, trans, inverse,
                   operation_budget ? operation_budget : default_budget, used);
    fplll::LLLReduction<Z, F> reduction(gso, 0.9, 0.501, fplll::LLL_DEFAULT);
    const bool ok = reduction.lll();
    if (operations_used) *operations_used = used;
    if (!ok) return 3;
    for (int i = 0; i < dim; ++i)
      for (int j = 0; j < dim; ++j) {
        transform[i * dim + j] = trans[i][j].get_si();
        if (reduced_basis) reduced_basis[i * dim + j] = basis[i][j].get_si();
      }
    return 0;
  } catch (const Rejected &r) {
    if (operations_used) *operations_used = used;
    return r.code;
  } catch (...) {
    if (operations_used) *operations_used = used;
    return 7;
  }
}

EXPORT int fplll_long18_transform(const std::int64_t *input,
                                 std::int64_t *transform) noexcept {
  return fplll_long18_transform_ex(input, transform, nullptr, 0, nullptr);
}

EXPORT const char *fplll_long18_version() noexcept {
  return "fplll 5.5.0; direct MatGSO<long,double>; delta=0.9 eta=0.501; row-bound guarded v2";
}
