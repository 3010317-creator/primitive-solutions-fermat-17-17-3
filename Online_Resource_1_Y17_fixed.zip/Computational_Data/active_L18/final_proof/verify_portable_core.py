"""Verify the portable exact data printed or cited in fullproof.tex.

This finite check uses independent FLINT rational-polynomial arithmetic and
plain Python finite-field linear algebra. It deliberately does not assert
class-group generation; the exhaustive ledger and strict audit are separate.
"""
from __future__ import annotations

import json
from fractions import Fraction
from pathlib import Path
from flint import fmpq, fmpq_poly, fmpq_mat

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent


def rank_mod(rows, p):
    a = [[int(v) % p for v in row] for row in rows]
    if not a:
        return 0
    r = 0
    for c in range(len(a[0])):
        pivot = next((i for i in range(r, len(a)) if a[i][c]), None)
        if pivot is None:
            continue
        a[r], a[pivot] = a[pivot], a[r]
        z = pow(a[r][c], -1, p)
        a[r] = [v * z % p for v in a[r]]
        for i in range(len(a)):
            if i != r and a[i][c]:
                z = a[i][c]
                a[i] = [(v - z*w) % p for v, w in zip(a[i], a[r])]
        r += 1
        if r == len(a):
            break
    return r


def product_matrix(a, b, p):
    return [[sum(x*y for x, y in zip(row, col)) % p
             for col in zip(*b)] for row in a]


def poly(values):
    return fmpq_poly([fmpq(str(v)) for v in values])


def evaluate(p, x, modulus):
    r = fmpq_poly([])
    for i in range(p.degree(), -1, -1):
        r = (r*x + p[i]) % modulus
    return r


def norm(a, modulus):
    n = modulus.degree()
    t = fmpq_poly([0, 1])
    columns = []
    b = a
    for _ in range(n):
        columns.append([b[i] for i in range(n)])
        b = (b*t) % modulus
    return fmpq_mat([[columns[j][i] for j in range(n)]
                     for i in range(n)]).det()


def main():
    d = json.loads((HERE/'proof_data.json').read_text())
    p = json.loads((HERE/'points_and_jmap.json').read_text())
    assert d['schema'] == 'x3-y17-final-proof-data-v1'
    assert p['schema'] == 'x3-y17-points-and-jmap-v1'
    g = poly(d['field_polynomial_ascending'])
    f = poly(p['field_polynomial_ascending'])
    assert g.degree() == f.degree() == 18
    gg = list(map(poly, d['fourteen_G_power_coefficients']))
    aa = list(map(poly, d['diagonal_A_power_coefficients']))
    squares = list(map(poly, d['diagonal_A_quotient_square_roots']))
    coords = d['diagonal_A_G_coordinate_columns']
    assert len(gg) == 14 and len(aa) == len(squares) == 11
    assert aa[0] == -1
    for j in range(11):
        z = fmpq_poly([1])
        for i in range(14):
            assert coords[i][j] in (0, 1)
            if coords[i][j]:
                z = (z*gg[i]) % g
        assert (z*squares[j]*squares[j] - aa[j]) % g == 0
    for unit in map(poly, d['ten_units_power_coefficients']):
        assert abs(norm(unit, g)) == 1
    assert rank_mod(d['class_and_unit_character_matrix'], 2) == 11
    assert rank_mod(d['G_character_matrix'], 2) == 14
    b = d['full2_constraint_matrix']
    k = d['full2_kernel_basis_columns']
    assert len(b) == 26 and all(len(r) == 28 for r in b)
    assert rank_mod(b, 2) == 15 and rank_mod(k, 2) == 13
    assert all(not any(row) for row in product_matrix(b, k, 2))
    diag = [[(r[i]+r[14+i]) % 2 for i in range(14)] for r in b]
    assert diag == [[v % 2 for v in row] for row in d['diagonal_constraint_matrix']]
    assert rank_mod(diag, 2) == 3 and rank_mod(coords, 2) == 11
    assert all(not any(row) for row in product_matrix(diag, coords, 2))
    assert rank_mod(d['opposite_constraint_matrix'], 2) == 12
    m = d['lower_pairing_matrix']
    assert len(m) == 11 and rank_mod(m, 2) == 6
    assert m == list(map(list, zip(*m))) and all(m[i][i] == 0 for i in range(11))
    supports = [[1], [5,7], [3,4,5,6,9], [3,4,10], [2,3,4,5,6,11]]
    radical = [[int(i+1 in supp) for supp in supports] for i in range(11)]
    assert rank_mod(radical, 2) == 5
    assert all(not any(row) for row in product_matrix(m, radical, 2))
    quotient_vectors = [[1,0,0,0,0], [0,1,0,1,1], [1,0,1,0,1],
                        [1,0,1,1,0], [1,1,0,0,1]]
    assert rank_mod(quotient_vectors, 2) == 5
    amap = poly(p['jmap_A_coefficients_ascending'])
    bmap = poly(p['jmap_B_coefficients_ascending'])
    for row in p['points']:
        x = poly(row['x_coefficients_ascending'])
        y = poly(row['y_coefficients_ascending'])
        assert (y*y+x*y+y-x*x*x+x*x+x+14) % f == 0
        numerator = (evaluate(amap, x, f) + evaluate(bmap, x, f)*y) % f
        denominator = (x-7)**17 % f
        assert denominator != 0
        assert (numerator-fmpq(row['j'])*denominator) % f == 0
    local = json.loads((ROOT/'L18_mod25_dimension3_certificate.json').read_text())
    compact = json.loads((ROOT/'L18_mod25_dimension3_compact_certificate.json').read_text())
    assert rank_mod(local['formal_log_matrix_divided_by5'], 5) == 3
    assert local['formal_log_matrix_divided_by5'][:3] == [[3,1,2],[4,2,3],[0,1,2]]
    surviving = []
    for full, short in zip(local['disks'], compact['disks']):
        assert full['frobenius_power'] == short['frobenius_power']
        rows = list(map(list, zip(*full['derivative_columns'])))
        assert len(rows) == 17 and rank_mod(rows, 5) == 3
        ids = short['minor_coefficient_indices']
        minor = [rows[i-1] for i in ids]
        assert minor == short['minor_matrix'] and rank_mod(minor, 5) == 3
        q = short['unique_parameters_from_minor']
        residuals = [(full['alpha'][i]+sum(a*c for a,c in zip(rows[i],q))) % 5
                     for i in range(17)]
        assert all(residuals[i-1] == 0 for i in ids)
        if short['excluded']:
            extra = short['contradicting_equation']
            i = extra['coefficient_index']-1
            assert rows[i] == extra['derivative_row']
            assert full['alpha'][i] == extra['alpha']
            assert residuals[i] == extra['residual'] != 0
        else:
            assert not any(residuals)
            surviving.append(short['frobenius_power'])
    assert surviving == [0,7,11]
    assert Fraction(27,8)*56**3 == 592704
    assert max(Fraction(q['j']) for q in p['points']) < 592704
    out = {
        'portable_exact_square_witnesses': 11,
        'exact_unit_norms': 10,
        'global_character_ranks': [11,14],
        'full2_constraint_rank': 15,
        'full2_kernel_dimension': 13,
        'diagonal_dimension': 11,
        'opposite_dimension': 2,
        'lower_pairing_rank': 6,
        'exact_curve_points_and_jvalues': 3,
        'primitive_formal_log_rank': 3,
        'all_disk_derivative_ranks': 3,
        'surviving_disks': surviving,
        'terminal_lower_bound': 592704,
        'status': 'PASS',
        'scope': 'Finite portable-data verification; class completeness and local-image completeness have separate verifiers.'
    }
    (HERE/'portable_core_verification.json').write_text(json.dumps(out,indent=2)+'\n')
    print('PORTABLE_EXACT_CORE_VERIFICATION_PASSED')


if __name__ == '__main__':
    main()
