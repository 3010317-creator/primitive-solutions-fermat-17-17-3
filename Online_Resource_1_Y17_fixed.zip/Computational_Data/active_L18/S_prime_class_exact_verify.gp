\\ Independent exact witness verification: no bnfisprincipal, no GRH class group.
default(parisizemax, 700000000);
run() = {
  my(C=read("S_prime_class_exact_witnesses.bin"),n=read("L18_nf_checkpoint.bin"), P, T, row,pr,alpha, q,j,e, decom, matches);
  P=C[3]; T=C[4];
  if(nfcertify(n)!=[],error("Uncertified integral basis"));
  if(C[1]!=n.pol || C[2]!=n.zk,error("Number field mismatch"));
  if(#T!=3,error("Wrong number of S-prime relations"));
  for(i=1,#T,
    row=T[i]; q=row[1];j=row[2];e=row[3];pr=row[4];alpha=row[5];
    if((i==1 && [q,j,e]!=[2,1,2]) || (i==2 && [q,j,e]!=[2,2,14]) || (i==3 && [q,j,e]!=[17,1,0]),error("Unexpected relation"));
    decom=idealprimedec(n,q);
    if(j>#decom || idealhnf(n,decom[j])!=idealhnf(n,pr),error("Prime ideal incorrect"));
    if(idealnorm(n,pr)!=q,error("Prime degree not one"));
    if(idealhnf(n,idealmul(n,idealpow(n,P,e),alpha))!=idealhnf(n,pr),error("Bad witness"));
    print("S_PRIME_IDEAL_EXACT_WITNESS_VERIFIED q=",q," index=",j," exp=",e);
  );
  print("S_PRIME_WITNESSES_FULLY_VERIFIED=1");
};
iferr(run(),err,print("S_PRIME_WITNESS_VERIFY_FAILED=",err);quit(1));
quit;
