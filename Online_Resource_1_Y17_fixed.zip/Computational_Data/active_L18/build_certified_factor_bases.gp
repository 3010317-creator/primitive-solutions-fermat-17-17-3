\\ Only builds bases. Membership in the original class subgroup is justified
\\ separately by the completed original-algorithm prime ranges.
default(parisizemax,1000000000);
b=read("L18_bnf_checkpoint.bin");n=b.nf;
V=List(b[5]);
{
forprime(q=2,50000,
 prs=idealprimedec(n,q);
 for(k=1,#prs,if(idealnorm(n,prs[k])<=50000,listput(V,prs[k])));
);
}
V=Set(Vec(V));
for(j=1,3,B0=[1000,10000,50000][j];W=Set(concat(b[5],select(pr->idealnorm(n,pr)<=B0,V)));writebin(Str("class_certification/factor_base_",B0,".bin"),W);print("ENLARGED_FACTOR_BASE=",[B0,#W]));
quit;
