\\ Independent exact algebra for the higher-isogeny covering chain.
\\ No field checkpoint, search result, or floating-point arithmetic is used.
default(nbthreads,1);
{
c='c; d='d; th='th; ps='ps; u='u; v='v; et='et; lam='lam;
g0='g0; g1='g1; g2='g2; g3='g3;
GG1=-17*g1^2-g3^2+g0^2;
GG2=-17*g2^2-g3^2+17*g0^2;
NC=2*(g3^2-9*g0^2-17*g1*g2);
if(NC+17*(g1+g2)^2!=-(GG1+GG2),error("Gamma-to-C has Kummer class -17"));
resC=4*NC^2*g3^2-NC*(NC^2+36*NC*g0^2+256*g0^4);
if(resC!=-4*NC*(GG1*(g3^2-17*g0^2)-17*g1^2*GG2),error("Gamma-to-C curve equation"));
print("EXACT_GAMMA_TO_C_AND_KUMMER_CLASS_MINUS_SEVENTEEN_OK");
Dq1=17*c^2+d^2-2*th^2-34*ps^2;
Dq2=34*c*d+2*th^2-34*ps^2;
z0=17*c^2+d^2; z1=4*th*ps; z2=d^2-17*c^2; z3=34*c*d;
Gq1=-17*z1^2-z3^2+z0^2;
Gq2=-17*z2^2-z3^2+17*z0^2;
if(Gq1!=Dq1*(17*c^2+d^2+2*th^2+34*ps^2)-Dq2*(34*c*d-2*th^2+34*ps^2),error("D-to-Gamma equation 1"));
if(Gq2,error("D-to-Gamma equation 2"));
fGamma=17*(z0-z2)*(z3-z0);
if(fGamma+2*(34*c*th)^2!=-578*c^2*(Dq1-Dq2),error("D-to-Gamma twist identity"));
print("EXACT_D_TO_GAMMA_AND_XI_MINUS_TWO_OK");

Eq1=34*u^2+4*u*v+et*th^2-68*et*ps^2;
Eq2=17*u^2-4*v^2-34*et*th^2+68*et*th*ps;
cc=-68*u^2-8*u*v;
dd=-34*u^2+8*v^2;
hh=-17*u^2-68*u*v-4*v^2;
jj=et*(th^2-68*th*ps+68*ps^2);
cp=et*(2*th^2-136*ps^2);
dp=et*(-68*th^2+136*th*ps);
if(cc-cp!=-2*Eq1 || dd-dp!=-2*Eq2,error("E-to-D coordinate equalities"));
if(17*cc^2+dd^2-34*cc*dd-4*hh^2,error("First parametrized conic"));
if(17*cp^2+dp^2+34*cp*dp-68*jj^2,error("Second parametrized conic"));
resD1=17*cc^2+dd^2-2*hh^2-34*jj^2;
resD2=34*cc*dd+2*hh^2-34*jj^2;
resIdeal=-Eq1*(17*(cc+cp)+34*dd)-Eq2*(dd+dp+34*cp);
if(resD1!=resIdeal || resD2!=resIdeal,error("E-to-D equation identities"));
fD=68*(17*cc-dd+2*hh)*(cc+dd-2*jj);
if(fD-et*(136*(17*u+2*v)*(th-2*ps))^2!=544*(17*u+2*v)^2*(Eq1+Eq2),error("E-to-D et-twist identity"));
print("EXACT_E_TO_D_AND_ETA_TWIST_OK");

DM1=[17,0,0,0;0,1,0,0;0,0,-2,0;0,0,0,-34];
DM2=[0,17,0,0;17,0,0,0;0,0,2,0;0,0,0,-34];
EM1=-2*[34,2,0,0;2,0,0,0;0,0,et,0;0,0,0,-68*et];
EM2=-2*[17,0,0,0;0,-4,0,0;0,0,-34*et,34*et;0,0,34*et,0];
detD=matdet(lam*DM1+DM2);
detE=matdet(lam*EM1+EM2);
if(detD!=34^2*(lam^2-1)*(lam^2-17),error("D pencil determinant"));
if(detE!=2^8*17*et^2*(lam^2+34*lam+17)*(lam^2-34*lam+17),error("E pencil determinant"));
if(detD/34^2!=lam^4-18*lam^2+17,error("D determinant quartic normalization"));
if(detE/(16*et)^2!=17*lam^4-19074*lam^2+4913,error("E determinant quartic normalization"));
\\ Jac(y^2=a*x^4+b*x^2+c): Y^2=X^3-2*b*X^2+(b^2-4*a*c)*X.
JD=[-2*(-18),(-18)^2-4*1*17];
JE=[-2*(-19074),(-19074)^2-4*17*4913];
if(JD!=[36,256],error("Jac(D) is C"));
if(JE!=[38148,363483392],error("Jac(E) coefficients"));
if([JE[1]/34^2,JE[2]/34^4]!=[33,272],error("Jac(E) scaling"));
if(subst(u*(u+16)*(u+17),u,u-16)!=u*(u-16)*(u+1),error("Jac(E) translation to F"));
print("EXACT_JACOBIAN_TWISTS_C_AND_F_OK");

\\ No ambiguity between the three nonzero F[2] classes is possible:
\\ only the quotient by (-1,0) has the Jacobian j-invariant of C.
EC=ellinit([0,36,0,256,0]);
Quot0=ellinit([0,30,0,289,0]);
Quot16=ellinit([0,-66,0,1,0]);
if(EC.j==Quot0.j || EC.j==Quot16.j,error("Nonunique quotient identification"));
print("EXACT_KERNEL_IDENTIFICATION_UNIQUE_C_QUOTIENT_OK");

WAB=[1,0,0,0,0;0,1,0,1,1;1,0,1,0,1;1,0,1,1,0;1,1,0,0,1];
if(matrank(Mod(WAB,2))!=5,error("Known points and two new quotient directions"));
print("EXACT_KNOWN_POINT_PLUS_SOURCE_TARGET_DIMENSION_FIVE_OK");
print("HIGHER_EXACT_MAP_AND_JACOBIAN_AUDIT_OK");
}
quit;
