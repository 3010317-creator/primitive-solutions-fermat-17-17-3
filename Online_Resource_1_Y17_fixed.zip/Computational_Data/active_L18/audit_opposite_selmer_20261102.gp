default(nbthreads,1);
default(parisizemax,1200000000);
read("simon_descent/X017_full2_local2.gp");
read("X017_local17_full2.gp");
{
N=read("L18_nf_checkpoint.bin");
FULL=read("simon_descent/provisional_full2_matrix_data.bin");
G=FULL[1];ng=#G;L2=FULL[4];M=matrix(0,ng);
for(k=1,#L2,
 D=L2[k][1];Img=L2[k][2];r=matsize(Img)[1]/2;
 Ip=Img[1..r,]+Img[r+1..2*r,];
 H=matker(Mod(Ip~,2))~;
 V=matrix(r,ng,i,j,x017_local2_squareclass(N,D,G[j])[i]);
 M=matconcat([M;lift(H*Mod(V,2))]);
 print("OPPOSITE_LOCAL_DYADIC_IMAGE_DIM=",[k,matrank(Mod(Ip,2))]);
);
p17=idealprimedec(N,17)[1];I17=FULL[5];
I17p=I17[1..2,]+I17[3..4,];
H17=matker(Mod(I17p~,2))~;
V17=matrix(2,ng,i,j,x017_local17_squareclass(N,p17,G[j])[i]);
if(matrank(Mod(I17p,2))<2,M=matconcat([M;lift(H17*Mod(V17,2))]));
print("OPPOSITE_LOCAL_17_IMAGE_DIM=",matrank(Mod(I17p,2)));
M=matconcat([M;matrix(N.r1,ng,i,j,(1-nfeltsign(N,G[j],i))/2)]);
K=lift(matker(Mod(M,2)));dim=matsize(K)[2];
print("OPPOSITE_INITIAL_SELMER_DIM_CONDITIONAL_ON_GLOBAL_INPUT=",dim);
P1=read("X017_P1_reduced_checkpoint.bin");u1=4*P1[1]-11;
v1=8*P1[2]+4*P1[1]+4;
if(v1^2!=u1*(u1^2+30*u1+289),error("Known point is not on the auxiliary curve"));
if(u1==0 || u1+17==0,error("Exceptional known point coordinates"));
t1=(u1+30+289/u1)/4;w1=v1*(1-289/u1^2)/8;
if(w1^2!=t1*(t1-16)*(t1+1),error("Known point image is not on F"));
if(4*u1*(t1+1)!=(u1+17)^2,error("Known point does not represent u1 in opposite Selmer group"));
print("OPPOSITE_BASIS_ACTUAL_POINT_IDENTITIES_OK");
for(j=1,dim,
 a=prod(i=1,ng,G[i]^K[i,j]);found=0;
 for(e=0,1,for(f=0,1,
  q=a/(17^e*u1^f);
  if(nfeltissquare(N,q,&sq),
   sq=nfbasistoalg(N,sq);if(sq^2!=q,error("Bad exact square witness"));
   print("OPPOSITE_CLASS_KNOWN_POINT_EXPONENTS=",[j,e,f]);found=1;break(2)
  );
 ));
 if(!found,error("Initial opposite class not represented by known points"));
);
if(dim!=2,error("Unexpected opposite initial Selmer dimension"));
print("OPPOSITE_INITIAL_SELMER_EXACT_LINEAR_AUDIT_OK");
A=read("simon_descent/provisional_diagonal11.bin");
KD=read("simon_descent/Cassels_known_diagonal_points.bin");
Low=read("simon_descent/Cassels_pairing_diagonal11.bin");
if(KD[1]!=lift(Low[3]),error("Known-point radical basis differs from lower pairing"));
Expected=[[0,1,0,1,1]~,[1,0,1,0,1]~];
for(j=1,2,
 KR=KD[2][j][4];kv=KD[2][j][5];kc=KD[2][j][6];ks=KD[2][j][7];
 if(KR[2]^2!=KR[1]*(KR[1]-16)*(KR[1]+1),error("Known diagonal point is not on F"));
 if(KR[1]==0,error("Unexpected exceptional diagonal point"));
 if(kv!=Expected[j] || lift(Mod(KD[1],2)*Mod(kv,2))!=kc,error("Known diagonal radical coordinates"));
 klass=prod(i=1,11,A[i]^kc[i]);
 if(KR[1]!=klass*ks^2,error("Stored exact diagonal square witness"));
 if(!nfeltissquare(N,KR[1]+1,&rs),error("Third Kummer coordinate not square"));
 rs=nfbasistoalg(N,rs);if(rs^2!=KR[1]+1,error("Known-point square-root identity"));
 uc=2*(KR[1]-8+KR[2]/rs);vc=2*uc*rs;
 if(vc^2!=uc*(uc^2+36*uc+256),error("Actual preimage is not on C"));
 if(uc!=klass*(ks*(1+KR[2]/(rs*KR[1])))^2,error("Actual C point has wrong phi class"));
 print("KNOWN_DIAGONAL_ACTUAL_C_POINT_CLASS_OK=",[j,kv~]);
);
if((-32)^2!=(-16)*((-16)^2+36*(-16)+256),error("Actual C point for class minus one"));
print("KNOWN_THREE_DIMENSIONAL_MORDELL_WEIL_SUBSPACE_AUDIT_OK");
}
quit;
