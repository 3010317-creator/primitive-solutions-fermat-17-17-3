"""Independent exact small computations for the modular entrance and exit."""
from fractions import Fraction
from math import gcd, prod
from pathlib import Path
import json
import sympy as sp

ROOT=Path(__file__).resolve().parent

def divisors(n):
    return [d for d in range(1,n+1) if n%d==0]

def phi(n):
    return sum(gcd(i,n)==1 for i in range(1,n+1))

def genus_x0(n):
    primes=[p for p in divisors(n) if p>1 and len(divisors(p))==2]
    mu=Fraction(n)*prod(Fraction(p+1,p) for p in primes)
    cusps=sum(phi(gcd(d,n//d)) for d in divisors(n))
    e2=sum((r*r+1)%n==0 for r in range(n))
    e3=sum((r*r+r+1)%n==0 for r in range(n))
    genus=1+mu/12-Fraction(e2,4)-Fraction(e3,3)-Fraction(cusps,2)
    assert genus.denominator==1
    return {'index':int(mu),'cusps':cusps,'elliptic_order2':e2,
            'elliptic_order3':e3,'cusp_dimension':int(genus)}

dimensions={}
for n in divisors(54):
    data=genus_x0(n)
    old=sum(dimensions[m]['new_dimension']*len(divisors(n//m))
            for m in divisors(n) if m<n)
    data['new_dimension']=data['cusp_dimension']-old
    dimensions[n]=data
assert dimensions[18]['cusp_dimension']==0
assert dimensions[54]['cusp_dimension']==4
assert dimensions[54]['new_dimension']==2

def invariants(a):
    a1,a2,a3,a4,a6=a
    b2=a1*a1+4*a2
    b4=2*a4+a1*a3
    b6=a3*a3+4*a6
    b8=a1*a1*a6+4*a2*a6-a1*a3*a4+a2*a3*a3-a4*a4
    c4=b2*b2-24*b4
    c6=-b2**3+36*b2*b4-216*b6
    disc=-b2*b2*b8-8*b4**3-27*b6**2+9*b2*b4*b6
    return tuple(sp.expand(v) for v in (c4,c6,disc))

def valuation(n,p):
    n=abs(int(n));v=0
    while n%p==0: v+=1;n//=p
    return v

def projective_count(a,p):
    a1,a2,a3,a4,a6=a
    return 1+sum((y*y+a1*x*y+a3*y-x**3-a2*x*x-a4*x-a6)%p==0
                 for x in range(p) for y in range(p))

def nodal_data_mod2(a):
    u,v=sp.symbols('u v')
    a1,a2,a3,a4,a6=a
    F=v*v+a1*u*v+a3*v-u**3-a2*u*u-a4*u-a6
    Fu,Fv=sp.diff(F,u),sp.diff(F,v)
    singular=[(x,y) for x in range(2) for y in range(2)
              if all(int(f.subs({u:x,v:y}))%2==0 for f in (F,Fu,Fv))]
    assert len(singular)==1
    x0,y0=singular[0]
    shifted=sp.Poly(F.subs({u:u+x0,v:v+y0}),u,v,modulus=2)
    tangent=sum(int(c)*u**i*v**j for (i,j),c in shifted.terms() if i+j==2)
    directions=[(x,y) for x,y in ((1,0),(0,1),(1,1))
                if int(tangent.subs({u:x,v:y}))%2==0]
    assert len(directions) in (0,2)
    return {'singular_point':singular[0],'tangent_directions':directions,
            'split':len(directions)==2,'a2':3-projective_count(a,2)}

X=sp.symbols('X')
c4,c6,disc=invariants([3*X,0,2,0,0])
assert c4==9*X*(9*X**3-16) or sp.expand(c4-9*X*(9*X**3-16))==0
assert sp.expand(disc-216*(X**3-2))==0
J=27*X**3*(9*X**3-16)**3/(8*(X**3-2))
assert sp.cancel(c4**3/disc-J)==0

curves={'54a_model':[1,-1,0,12,8],
        '54b_model':[1,-1,1,1,-1],
        'reference':[3,0,2,0,0]}
curve_data={}
for name,a in curves.items():
    c4,c6,disc=invariants(a)
    nd=nodal_data_mod2(a)
    assert int(c4)%2==1 and valuation(disc,2)==3
    curve_data[name]={'coefficients':a,'c4':int(c4),'c6':int(c6),
                     'discriminant':int(disc),'minimal_discriminant_valuation2':3,
                     'reduction_mod2':nd,'a5':6-projective_count(a,5)}
assert curve_data['54a_model']['reduction_mod2']['a2']==-1
assert curve_data['54b_model']['reduction_mod2']['a2']==1
assert curve_data['reference']['a5']==-3

trace_rows=[]
for x in range(5):
    good=(216*(x**3-2))%5!=0
    count=projective_count([3*x,0,2,0,0],5)
    trace_rows.append({'X_mod5':x,'good_reduction':good,'projective_points':count,
                       'a5':6-count if good else None})
assert trace_rows==json.loads((ROOT/'X017_Frey_trace5_certificate.json').read_text())
assert [r['X_mod5'] for r in trace_rows if r['good_reduction'] and (r['a5']+3)%17==0]==[1]
squares=sorted({i*i%17 for i in range(17)})
assert 6 not in squares and (-3)**2-4*5 == -11
assert 6%17 != -3%17 and -6%17 != -3%17
assert (9261%5)*pow(8,-1,5)%5==2

assert Fraction(27*343,8)*8**3==592704
js=[Fraction(9261,8),Fraction(-132651,2),Fraction(-1167051,512)]
assert all(j<592704 for j in js)

out={'level_dimensions_by_genus_and_oldform_multiplicity':dimensions,
     'curve_invariants_and_local_counts':curve_data,
     'Frey_trace5_rows_match_previous_certificate':True,
     'Frey_invariants_symbolically_verified':True,
     'quadratic_residues_mod17':squares,
     'GL2_order':(17**2-1)*(17**2-17),
     'line_stabilizer_order':17*(17-1)**2,'line_orbit_degree':18,
     'candidate_j_values':[str(j) for j in js],
     'strict_lower_bound_for_X_at_least_2':592704,
     'scope':'Exact small computations only; BVY theorem hypotheses are audited in prose.'}
(ROOT/'X017_modular_reduction_independent_audit.json').write_text(json.dumps(out,indent=2)+'\n')
print('MODULAR_ENTRANCE_EXIT_INDEPENDENT_AUDIT_PASSED')
