\\ Exact quadratic-form constructions used in Fisher's next isogeny descent.
{cas_conic_param(M,V)=
  my(k=0,ids=List(),U,W,Bu,Bw,P,cert=vector(5));
  V=Vec(V)~;
  if(V~*M*V,error("Conic parametrization point fails exact identity"));
  for(i=1,3,if(V[i]!=0,k=i;break));
  if(k==0,error("Zero conic point"));
  for(i=1,3,if(i!=k,listput(ids,i)));ids=Vec(ids);
  U=vector(3,i,if(i==ids[1],1,0))~;W=vector(3,i,if(i==ids[2],1,0))~;
  Bu=V~*M*U;Bw=V~*M*W;
  P=matrix(3,3);
  P[,1]=(U~*M*U)*V-2*Bu*U;
  P[,2]=2*(U~*M*W)*V-2*Bu*W-2*Bw*U;
  P[,3]=(W~*M*W)*V-2*Bw*W;
  for(i=1,3,for(j=1,3,for(u=1,3,for(v=1,3,cert[u+v-1]+=M[i,j]*P[i,u]*P[j,v]))));
  if(cert!=vector(5),error("Conic parametrization polynomial identity fails"));
  if(matdet(P)==0,error("Degenerate conic parametrization"));
  [P,k,ids];
}
{cas_form_matrix(v)=[v[1],v[2]/2;v[2]/2,v[3]];}
{cas_linear_ball(N,p,T,P)=
  my(v=cas_ball_exact(0));
  for(i=1,#T,v=cas_ball_add(N,p,v,cas_ball_scale(N,p,T[i],P[i])));
  v;
}
{cas_conic_inverse_param_ball(N,p,V,Par,P)=
  my(k=Par[2],ids=Par[3],c=cas_ball_scale(N,p,1/V[k],P[k]));
  vector(2,i,cas_ball_sub(N,p,P[ids[i]],cas_ball_scale(N,p,V[ids[i]],c)));
}
{cas_build_D_tangents(N,J,Norms)=
  my(a=J[1],r=J[2][1],h=J[2][3],xi=J[8],mm,mp,vm,vp,Ap,Bp,Am,Bm,tm,tp,Pm,Pp,Cm,Cp);
  Am=-17*(r+h);Bm=17*h+r;Ap=-17*(r-h);Bp=17*h-r;
  if(Am==0||Ap==0,error("Degenerate completing-square coordinate"));
  vm=[(Norms[1][1]-Bm*Norms[1][2]/4)/Am,Norms[1][2]/4,Norms[1][3]];
  vp=[(Norms[2][1]-Bp*Norms[2][2]/4)/Ap,Norms[2][2]/4,Norms[2][3]];
  mm=[Am,Bm,0;Bm,-(r+h),0;0,0,-2*xi];
  mp=[Ap,Bp,0;Bp,-(r-h),0;0,0,-2*a*xi];
  if(vm*mm*vm~||vp*mp*vp~,error("D cone point verification fails"));
  tm=Vec(mm*vm~);tp=Vec(mp*vp~);
  tm=[tm[1],tm[2],tm[3],0];tp=[tp[1],tp[2],0,tp[3]];
  Pm=cas_conic_param(mm,vm);Pp=cas_conic_param(mp,vp);
  Cm=idealadd(N,idealadd(N,vm[1],vm[2]),vm[3]);
  Cp=idealadd(N,idealadd(N,vp[1],vp[2]),vp[3]);
  [mm,mp,vm,vp,tm,tp,Pm,Pp,Cm,Cp];
}
{cas_E_model(Pm,Pp,eta)=
  my(E1=matrix(4,4),E2=matrix(4,4),am,bm,ap,bp);
  am=cas_form_matrix(Pm[1][1,]);bm=cas_form_matrix(Pm[1][2,]);
  ap=-eta*cas_form_matrix(Pp[1][1,]);bp=-eta*cas_form_matrix(Pp[1][2,]);
  for(i=1,2,for(j=1,2,E1[i,j]=am[i,j];E2[i,j]=bm[i,j];E1[i+2,j+2]=ap[i,j];E2[i+2,j+2]=bp[i,j]));
  [E1,E2];
}
{cas_lift_D_to_E(N,p,TD,eta,P,fp,bits=128)=
  my(vm=TD[3],vp=TD[4],tm=TD[5],tp=TD[6],Pm=TD[7],Pp=TD[8],um,up,Lm,Lp,f,R,scale);
  um=cas_conic_inverse_param_ball(N,p,vm,Pm,[P[1],P[2],P[3]]);
  up=cas_conic_inverse_param_ball(N,p,vp,Pp,[P[1],P[2],P[4]]);
  Lm=cas_linear_ball(N,p,tm,P);Lp=cas_linear_ball(N,p,tp,P);
  f=cas_ball_mul(N,p,Lm,Lp);
  R=cas_sqrt_ball(N,p,cas_ball_scale(N,p,1/eta,f),fp,bits);
  scale=cas_ball_div(N,p,R,Lp);
  concat(um,vector(2,i,cas_ball_mul(N,p,scale,up[i])));
}
