\\ Read-only replay of the completed higher-pairing certificate.
\\ This does not perform, assume, or replace global Selmer completeness.
default(nbthreads,1);
default(parisizemax,1800000000);
allocatemem(134217728);
read("simon_descent/Cassels_higher_local.gp");
read("simon_descent/Cassels_higher_models.gp");
read("simon_descent/Cassels_higher_E_pushout.gp");
read("simon_descent/X017_full2_local2.gp");
read("simon_descent/Cassels_E_odd_content.gp");
{cas_higher_readonly_replay()=
  my(N,MP,NM,S,H,Low,A,B,cvA,cvB,K,NP,QP,P,Push,Data,Odd,Final,DC,CH,LD,Pts,hs,FB,cl,eq,Mnorm,FC,C,Recon,Bup,odd=1,details=List(),fac,nu,v,p,unit,mp,leg,pi);
  N=read("L18_nf_checkpoint.bin");MP=read("simon_descent/Cassels_E_conic_M17_lowdisc_preparation.bin");NM=MP[1].nf;
  if(#nfcertify(N) || #nfcertify(NM),error("Maximal-order certificate failed"));
  if(NM.disc!=N.disc^2,error("M/L unramified discriminant identity failed"));
  S=read("simon_descent/Cassels_higher_lowdisc_static_certificate.bin");
  H=read("simon_descent/Cassels_higher_lowdisc_second_lift.bin");Low=read("simon_descent/Cassels_pairing_diagonal11.bin");
  A=read("simon_descent/provisional_diagonal11.bin");cvA=S[1];cvB=S[2];B=S[5];K=lift(Low[3]);
  if(matrank(Mod(Low[1],2))!=6 || matsize(K)[2]!=5,error("Lower pairing rank is not six"));
  if(lift(Mod(Low[1],2)*Mod(cvA,2))!=vector(11)~ || lift(Mod(Low[1],2)*Mod(cvB,2))!=vector(11)~,error("Source/target not in lower radical"));
  if(prod(i=1,11,A[i]^cvA[i])!=-17*S[4]^2 || prod(i=1,11,A[i]^cvB[i])!=B,error("Source or target representative identity failed"));
  if(matrank(Mod(matconcat([S[8],S[6],S[7]]),2))!=5 || matrank(Mod(S[8],2))!=3,error("Unknown quotient independence failed"));
  if(lift(Mod(H[8],2)*Mod(H[10],2))!=H[9]~,error("Second twist affine condition failed"));
  if(prod(i=1,#H[7],H[7][i]^H[10][i])!=H[11],error("Second twist generator identity failed"));
  if(idealnorm(N,rnfdisc(N,'x^2-H[11])[1])!=17,error("Selected twist relative discriminant differs from 17"));
  if(nfeltsign(N,B)!=[1,1] || !cas_islocal_square(N,idealprimedec(N,17)[1],B),error("Trivial real/17 factors are not justified"));
  NP=read("simon_descent/Cassels_E_lowdisc_eta_norm_witness.bin");
  if(NP!=read("simon_descent/Cassels_E_lowdisc_eta_norm_witness_from_base.bin"),error("Independent norm witness copies disagree"));
  QP=read("simon_descent/Cassels_E_base_quadric_lowdisc_soluble.bin");P=read("simon_descent/Cassels_E_base_quadric_lowdisc_point.bin");
  if(cas_E_basequadric_to_norm(N,MP,QP,P)!=NP,error("Base quadric conversion replay failed"));
  Push=cas_E_pushout_build(N,MP,NP,H[12]);Data=read("simon_descent/Cassels_higher_lowdisc_pushout_data.bin");
  if(Push!=Data[1] || Data[2]!=B,error("Exact pushout reconstruction differs from saved certificate"));
  print("HIGHER_REPLAY_GLOBAL_IDENTITIES_PASSED");
  LD=read("simon_descent/full2_local2_images.bin");Pts=read("simon_descent/Cassels_higher_lowdisc_E_local2_points.bin");
  DC=read("simon_descent/Cassels_E_final_dyadic_independent_certificate.bin");CH=DC[2];
  if(DC[1]!=B || x017_local2_squareclass(N,LD[1][1],B)==vector(19),error("Target character input is wrong"));
  Mnorm=matrix(19,#CH[3]);
  for(j=1,#CH[3],
    if(CH[3][j][1]^2-B*CH[3][j][2]^2!=CH[3][j][3],error("Exact norm-hyperplane witness fails"));
    Mnorm[,j]=x017_local2_squareclass(N,LD[1][1],CH[3][j][3])~;
  );
  if(Mnorm!=CH[2] || matrank(Mod(Mnorm,2))!=18,error("Norm hyperplane is not complete"));
  if(lift(matker(Mod(Mnorm~,2)))[,1]!=CH[1] || CH[1]!=Data[4],error("Target Hilbert character disagrees"));
  fac=vector(5,i,1);
  for(k=1,2,
    p=Pts[k][1];if(p!=LD[k][1][1] || p!=Data[5][k][1],error("Local prime ordering mismatch"));
    eq=vector(2,j,cas_quad_ball(N,p,H[12][j],Pts[k][4]));
    for(j=1,2,if(cas_val(N,p,eq[j][1])<eq[j][2],error("Certified E-point residual replay fails")));
    FB=cas_quad_ball(N,p,Push[6],Pts[k][4]);v=cas_val(N,p,FB[1]);
    if(FB[2]-v<=2*p[3],error("Pushout precision does not determine its squareclass"));
    cl=x017_local2_squareclass(N,LD[k][1],FB[1]);
    hs=if(k==1,(-1)^lift(Mod(cl*CH[1],2)),cas_E_q2_hilbert(N,p,FB[1],B));
    if(hs!=Data[5][k][4] || cl!=Data[5][k][3],error("Dyadic factor replay failed"));fac[k]=hs;
  );
  print("HIGHER_REPLAY_DYADIC_FACTORS=",fac[1..2]);
  Odd=read("simon_descent/Cassels_E_lowdisc_good_odd_correction.bin");FC=Odd[1][3];
  C=cas_E_linear_content(NM,Push[3]);Recon=matid(36);Bup=subst(lift(B),'y,Push[7][1]);
  for(i=1,matsize(FC)[1],
    p=FC[i,1];v=FC[i,2];if(!isprime(p[1]),error("Content support includes an unproved prime"));
    Recon=idealmul(NM,Recon,idealpow(NM,p,v));
    if(vecmin(vector(4,j,nfeltval(NM,Push[3][j],p)))!=v,error("Content valuation differs from actual tangent minimum"));
    if(p[1]==2 || p[1]==17 || v%2==0,next);
    nu=nfeltval(NM,Bup,p);if(nu%2,error("Target has odd good-prime valuation"));
    pi=nfbasistoalg(NM,p[2]);if(nfeltval(NM,pi,p)!=1,pi=nfbasistoalg(NM,idealappr(NM,p)));
    unit=Bup/pi^nu;mp=nfmodprinit(NM,p);leg=if(issquare(nfmodpr(NM,unit,mp)),1,-1);
    odd*=leg;listput(details,[p[1],p[4],v,leg]);
  );
  if(idealhnf(NM,Recon)!=idealhnf(NM,C) || C!=Odd[1][2],error("Complete content factorization reconstruction failed"));
  if(odd!=(-1)^Odd[1][1][1],error("Finite-field odd product differs from original Hilbert product"));fac[3]=odd;
  Final=read("simon_descent/Cassels_higher_lowdisc_final_pairing_certificate.bin");
  if(fac!=Final[4] || prod(i=1,5,fac[i])!=Final[5] || Final[5]!=-1,error("Final pairing product failed"));
  print("HIGHER_REPLAY_ODD_FACTORS=",Vec(details));print("HIGHER_REPLAY_ALL_FACTORS=",fac);
  print("HIGHER_PAIRING_READONLY_REPLAY_OK_VALUE_MINUS_ONE");
  print("RANK3_STILL_REQUIRES_SEPARATE_GLOBAL_SELMER_COMPLETENESS");
}
iferr(cas_higher_readonly_replay(),E,print("HIGHER_REPLAY_FATAL=",E);quit(1));
quit;
