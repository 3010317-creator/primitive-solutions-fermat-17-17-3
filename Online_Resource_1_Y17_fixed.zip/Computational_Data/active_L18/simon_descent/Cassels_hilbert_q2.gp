{x017_q2_unitmod8(N,p,u) =
  for(r=1,7,if(r%2 && nfeltval(N,u-r,p)>=3,return(r)));
  error("Q2 unit mod8 identification failed");
}
{x017_q2_hilbert(N,p,a,b) =
  my(ua,ub,va,vb,ra,rb,e);
  if(p[3]!=1||p[4]!=1,error("Not a Q2 local prime"));
  va=nfeltval(N,a,p);vb=nfeltval(N,b,p);ua=a/2^va;ub=b/2^vb;
  ra=x017_q2_unitmod8(N,p,ua);rb=x017_q2_unitmod8(N,p,ub);
  e=((ra-1)/2)*((rb-1)/2)+va*(rb^2-1)/8+vb*(ra^2-1)/8;
  return((-1)^(e%2));
}
