\\ Certified local ball arithmetic for subsequent isogeny coverings.
read("simon_descent/Cassels_local2.gp");
{cas_ball_inv(N,p,A)=
  my(v=cas_val(N,p,A[1]));
  if(A[2]<=v,error("Cannot invert an uncertified nonzero local ball"));
  [1/A[1],A[2]-2*v];
}
{cas_ball_div(N,p,A,B)=cas_ball_mul(N,p,A,cas_ball_inv(N,p,B));}
{cas_local_model_any(N,p,bits=128)=
  my(fs=factorpadic(N.pol,p[1],bits),fp=0,n=0,best=-1000000,v);
  for(i=1,matsize(fs)[1],if(poldegree(fs[i,1])==p[3]*p[4],
    v=cas_val(N,p,Mod(liftall(fs[i,1]),N.pol));
    if(v>best,fp=fs[i,1];best=v;n=1,if(v==best,n++));
  ));
  if(n!=1,error("Local polynomial factor was not identified uniquely"));
  fp;
}
{cas_root_near1_any(N,p,h,fp,bits=128)=
  my(hp,z,zlift,err,der,v2=nfeltval(N,2,p),q=p[1]);
  if(cas_val(N,p,h-1)<=2*v2,error("Root is not in near-one Hensel range"));
  hp=subst(lift(h),'y,Mod('y,fp))*(1+O(q^bits));
  z=Mod(1+O(q^bits),fp);
  for(k=1,18,z=z*(3-hp*z^2)/2);
  z=hp*z;zlift=Mod(liftall(z),N.pol);
  err=cas_val(N,p,zlift^2-h);der=cas_val(N,p,2*zlift);
  if(err<=2*der,error("Near-one root residual certificate failed"));
  if(cas_val(N,p,zlift-1)<=v2,error("Near-one root branch check failed"));
  [zlift,err-der];
}
{cas_powmodideal(N,a,k,I)=
  my(r=Mod(1,N.pol),b=nfbasistoalg(N,nfeltreduce(N,a,I)));
  if(k<0,error("Negative modular exponent"));
  while(k,
    if(k%2,r=nfbasistoalg(N,nfeltreduce(N,r*b,I)));
    k=k\2;
    if(k,b=nfbasistoalg(N,nfeltreduce(N,b*b,I)));
  );
  r;
}
{cas_islocal_square(N,p,a)=
  my(v,u,mp);
  if(a==0,return(1));
  if(p[1]==2,return(nfislocalpower(N,p,a,2)));
  v=nfeltval(N,a,p,&u);
  if(v%2,return(0));
  mp=nfmodprinit(N,p);
  return(issquare(nfmodpr(N,nfbasistoalg(N,u),mp)));
}
{cas_sqrt_ball(N,p,H,fp,bits=128)=
  my(v=cas_val(N,p,H[1]),v2=nfeltval(N,2,p),pi,u,I,bid,logs,r0,R,der,prec,q=p[1],mp,ur,sr);
  if(H[2]<=v+2*v2,error("Input ball has no certified squareclass"));
  if(v%2,error("Square-root input has odd valuation"));
  pi=nfbasistoalg(N,p[2]);
  if(nfeltval(N,pi,p)!=1,error("Invalid local uniformizer"));
  u=H[1]/pi^v;r0=Mod(1,N.pol);
  if(q==2,
    I=idealpow(N,p,2*v2+1);bid=idealstar(N,I,2);logs=ideallog(N,u,bid);
    for(i=1,#logs,
      if(bid.cyc[i]%2==0 && logs[i]%2,error("Square-root input is not a local square"));
      my(e=if(bid.cyc[i]%2,lift(Mod(2,bid.cyc[i])^-1)*logs[i]%bid.cyc[i],logs[i]/2));
      r0=nfbasistoalg(N,nfeltreduce(N,r0*cas_powmodideal(N,nfbasistoalg(N,bid.gen[i]),e,I),I));
    );
  ,
    mp=nfmodprinit(N,p);ur=nfmodpr(N,u,mp);
    if(!issquare(ur,&sr),error("Odd-prime unit is not a square"));
    r0=nfbasistoalg(N,nfmodprlift(N,sr,mp));
  );
  r0*=pi^(v/2);
  R=cas_root_near1_any(N,p,H[1]/r0^2,fp,bits);
  R=cas_ball_scale(N,p,r0,R);
  der=cas_val(N,p,2*R[1]);
  prec=min(R[2],H[2]-der);
  if(prec<=der,error("Square-root precision was exhausted"));
  [R[1],prec];
}
{cas_diagonal_point2(N,p,a,Q,bits=128,scale=3,rqsign=1)=
  my(va=nfeltval(N,a,p),pi,c,u,d,fp,Rf,Rq,Rh,Rj,Ya,Yq,Mn,Bn,Z2n,Z3n,C2,z1,z2,z3);
  if(va%2,error("Odd dyadic valuation"));
  pi=nfbasistoalg(N,p[2]);c=scale/pi^(va/2);u=a*c^2;d=4*(u-1);
  if(nfeltval(N,u,p)!=0||d==0,error("Invalid chord parameter"));
  fp=cas_local_model(N,p,bits);
  Rf=cas_root_near1(N,p,(1-4/u)*(1+4*u),fp,bits);
  Rq=cas_ball_scale(N,p,rqsign,cas_root_near1(N,p,-15,fp,bits));
  Rh=cas_root_near1(N,p,-3*(1-4/u),fp,bits);
  Rj=cas_root_near1(N,p,5*(1+4*u),fp,bits);
  Ya=cas_ball_scale(N,p,4*u,Rf);Yq=cas_ball_scale(N,p,4,Rq);
  Mn=cas_ball_sub(N,p,Ya,Yq);
  Bn=cas_ball_scale(N,p,4,cas_ball_sub(N,p,cas_ball_scale(N,p,u,Yq),Ya));
  Z2n=cas_ball_add(N,p,cas_ball_scale(N,p,16,Mn),Bn);
  Z3n=cas_ball_sub(N,p,Bn,Mn);C2=cas_ball_scale(N,p,4*a*c,Rh);
  z1=cas_ball_scale(N,p,1/(4*a*c*d),Bn);
  z2=cas_ball_div(N,p,Z2n,cas_ball_scale(N,p,d,C2));
  z3=cas_ball_div(N,p,Z3n,cas_ball_scale(N,p,d,Rj));
  [cas_ball_exact(1),z1,z2,z3];
}
{cas_diagonal_tangents(N,p,a,Q,P)=
  my(L1,L2,L3);
  L1=cas_ball_add(N,p,cas_ball_sub(N,p,cas_ball_scale(N,p,a*Q[2],P[3]),cas_ball_scale(N,p,Q[1],P[4])),cas_ball_scale(N,p,17*Q[3],P[1]));
  L2=cas_ball_sub(N,p,P[4],P[1]);L3=cas_ball_sub(N,p,P[2],P[3]);
  [L1,L2,L3];
}
{cas_lift_diagonal_to_D(N,p,a,Q,xi,P,fp,bits=128)=
  my(L=cas_diagonal_tangents(N,p,a,Q,P),f,R,c,d,th,ps);
  f=cas_ball_mul(N,p,L[1],L[2]);
  R=cas_sqrt_ball(N,p,cas_ball_scale(N,p,1/xi,f),fp,bits);
  c=cas_ball_sub(N,p,P[1],cas_ball_scale(N,p,Q[3],P[3]));
  d=cas_ball_sub(N,p,P[4],cas_ball_scale(N,p,Q[1],P[3]));
  th=R;ps=cas_ball_scale(N,p,-1,cas_ball_div(N,p,cas_ball_mul(N,p,R,P[2]),L[2]));
  [c,d,th,ps];
}
{cas_quad_ball(N,p,M,P)=
  my(R=cas_ball_exact(0),n=#P);
  for(i=1,n,
    R=cas_ball_add(N,p,R,cas_ball_scale(N,p,M[i,i],cas_ball_mul(N,p,P[i],P[i])));
    for(j=i+1,n,R=cas_ball_add(N,p,R,cas_ball_scale(N,p,2*M[i,j],cas_ball_mul(N,p,P[i],P[j]))));
  );
  R;
}
{cas_F_add_ball(N,p,P,Q,doubling=0)=
  my(m,x,y,num);
  if(doubling,
    num=cas_ball_add(N,p,cas_ball_sub(N,p,cas_ball_scale(N,p,3,cas_ball_mul(N,p,P[1],P[1])),cas_ball_scale(N,p,30,P[1])),cas_ball_exact(-16));
    m=cas_ball_div(N,p,num,cas_ball_scale(N,p,2,P[2]));
  ,
    m=cas_ball_div(N,p,cas_ball_sub(N,p,Q[2],P[2]),cas_ball_sub(N,p,Q[1],P[1]));
  );
  x=cas_ball_sub(N,p,cas_ball_sub(N,p,cas_ball_add(N,p,cas_ball_mul(N,p,m,m),cas_ball_exact(15)),P[1]),Q[1]);
  y=cas_ball_sub(N,p,cas_ball_mul(N,p,m,cas_ball_sub(N,p,P[1],x)),P[2]);
  [x,y];
}
{cas_diagonal_from_F_double(N,p,a,P,ra)=
  my(t=P[1],w=P[2],t2,den,n1,n2,n3);
  t2=cas_ball_mul(N,p,t,t);den=cas_ball_scale(N,p,2,w);
  n1=cas_ball_add(N,p,t2,cas_ball_exact(16));
  n2=cas_ball_add(N,p,cas_ball_sub(N,p,t2,cas_ball_scale(N,p,32,t)),cas_ball_exact(-16));
  n3=cas_ball_add(N,p,cas_ball_add(N,p,t2,cas_ball_scale(N,p,2,t)),cas_ball_exact(-16));
  [cas_ball_exact(1),cas_ball_div(N,p,n1,cas_ball_mul(N,p,den,ra)),cas_ball_div(N,p,n2,cas_ball_mul(N,p,den,ra)),cas_ball_div(N,p,n3,den)];
}
