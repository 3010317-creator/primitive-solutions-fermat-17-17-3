\\ Odd good-place correction for f_E(P)=Norm_{M/L}(T(P)).
\\ Inputs: exact maximal-order nf structures NL, NM, embedding alpha of L's
\\ generator in M, actual 4-coefficient tangent T, and target classes in L.
\\ This computes only good finite places; dyadic, 17-adic and real terms remain separate.

{cas_E_linear_content(NM,T)=
  my(C=idealhnf(NM,0));
  if(#T==0,error("Empty tangent coefficient vector"));
  for(i=1,#T,C=idealadd(NM,C,T[i]));
  if(C==matrix(poldegree(NM.pol),0),error("Zero tangent"));
  C;
}
{cas_E_good_odd_content_row(NL,NM,alpha,T,Targets,bad=[2,17])=
  my(C,FC,up,rows,details=List(),bF,pr,v,pi,hs,alphapol,reconstructed);
  if(poldegree(NM.pol)!=2*poldegree(NL.pol),error("Relative degree must be two"));
  if(NM.disc!=NL.disc^2,error("M/L is not verified everywhere finitely unramified"));
  if(subst(NL.pol,variable(NL.pol),alpha)!=0,error("Base-field embedding fails"));
  up=vector(#Targets,j,subst(lift(Targets[j]),variable(NL.pol),alpha));
  for(j=1,#Targets,
    bF=idealfactor(NL,Targets[j]);
    for(i=1,matsize(bF)[1],if(!setsearch(Set(bad),bF[i,1][1]) && bF[i,2]%2,error("Target has an odd valuation outside the bad support")));
  );
  C=cas_E_linear_content(NM,T);FC=idealfactor(NM,C);rows=vector(#Targets);
  reconstructed=matid(poldegree(NM.pol));
  for(i=1,matsize(FC)[1],
    if(!isprime(FC[i,1][1]),error("A content-support rational prime was not proved prime"));
    reconstructed=idealmul(NM,reconstructed,idealpow(NM,FC[i,1],FC[i,2]));
  );
  if(idealhnf(NM,reconstructed)!=idealhnf(NM,C),error("Content ideal factorization does not reconstruct the actual ideal"));
  for(i=1,matsize(FC)[1],
    pr=FC[i,1];v=FC[i,2];if(setsearch(Set(bad),pr[1])||v%2==0,next);
    pi=nfbasistoalg(NM,pr[2]);
    if(nfeltval(NM,pi,pr)!=1,pi=nfbasistoalg(NM,idealappr(NM,pr)));
    if(nfeltval(NM,pi,pr)!=1,error("Uniformizer construction failed"));
    hs=vector(#Targets);
    for(j=1,#Targets,
      if(nfeltval(NM,up[j],pr)%2,error("Target-up valuation parity failed"));
      hs[j]=nfhilbert(NM,pi,up[j],pr);
      rows[j]=(rows[j]+(1-hs[j])/2)%2;
    );
    listput(details,[pr,v,hs]);
  );
  [rows,C,FC,Vec(details),up];
}

\\ If Q is expressed in the original good conic coordinates, one may replace
\\ T-content by Q-content only after this exact check. Completion of squares
\\ can introduce the prime 137, so raw norm-equation coordinates are not assumed good.
{cas_E_compare_conic_tangent_content(NM,Q,T,bad=[2,17])=
  my(CQ=cas_E_linear_content(NM,Q),CT=cas_E_linear_content(NM,T),R,F);
  R=idealdiv(NM,CT,CQ);F=idealfactor(NM,R);
  for(i=1,matsize(F)[1],if(!setsearch(Set(bad),F[i,1][1]),return([0,CQ,CT,F])));
  [1,CQ,CT,F];
}
