\\ Exact construction of the final pushout from the M=L(sqrt(17)) conic.
\\ Every input witness is verified as an identity in M before use.
\\ No class-group or point-search claim is made by this module.

{cas_E_M_embedding(N,Prep)=
  my(BM=Prep[1],s=Prep[2],al,V,iv,n=poldegree(N.pol),m=poldegree(BM.pol));
  if(m!=2*n,error("Unexpected relative degree"));
  al=Mod(subst(lift(Prep[6]),'x,'y),BM.pol);
  if(s^2!=17 || subst(N.pol,'y,al)!=0,error("M/L embedding identity fails"));
  V=matrix(m,m);
  for(j=1,n,
    my(a=lift(al^(j-1)),b=lift(s*al^(j-1)));
    for(i=1,m,V[i,j]=polcoef(a,i-1,'y);V[i,j+n]=polcoef(b,i-1,'y));
  );
  iv=V^-1;
  if(V*iv!=matid(m),error("M/L coefficient conversion is not invertible"));
  [al,s,V,iv];
}

{cas_E_M_split(N,Prep,Emb,z)=
  my(m=poldegree(Prep[1].pol),n=poldegree(N.pol),v,c,a,b);
  v=vector(m,i,polcoef(lift(z),i-1,'y))~;c=Emb[4]*v;
  a=Mod(sum(i=1,n,c[i]*'y^(i-1)),N.pol);
  b=Mod(sum(i=1,n,c[i+n]*'y^(i-1)),N.pol);
  if(subst(lift(a),'y,Emb[1])+Emb[2]*subst(lift(b),'y,Emb[1])!=z,error("M/L coefficient split identity fails"));
  [a,b];
}

{cas_E_pushout_build(N,Prep,NormPoint,EM)=
  my(BM=Prep[1],s=Prep[2],eta=Prep[3],lam=Prep[4],Emb,x,y,z,U0,V0,K,U,V,zq,th,ps,Q,T,T0,T1,F,emM,pencil);
  if(#NormPoint!=3,error("Norm witness must have three coordinates"));
  x=NormPoint[1];y=NormPoint[2];z=NormPoint[3];
  if(x==0 && y==0 && z==0,error("Zero norm witness"));
  if(x^2+lam*y^2!=eta*z^2,error("Norm-eta witness exact identity fails"));
  U0=(3*s-17)/2;V0=-(5*s+13)/2;K=-4*(34-lam);
  if(U0^2+lam*V0^2!=K,error("Constant norm identity fails"));
  U=U0*x+lam*V0*y;V=V0*x-U0*y;zq=eta*z;
  if(U^2+lam*V^2!=K/eta*zq^2,error("Composed norm identity fails"));
  th=(U+V/2)/(34-lam);ps=V/68;
  if(4*zq^2+eta*((34-lam)*th^2-68*th*ps+68*lam*ps^2),error("Final conic identity fails"));
  Q=[0,zq,th,ps];
  T=[-2*lam*zq,4*zq,eta*((34-lam)*th-34*ps),eta*(-34*th+68*lam*ps)];
  Emb=cas_E_M_embedding(N,Prep);
  emM=vector(2,k,matrix(4,4,i,j,subst(lift(EM[k][i,j]),'y,Emb[1])));
  pencil=lam*emM[1]+emM[2];
  if(Q*pencil*Q~ || Vec(pencil*Q~/2)!=T,error("Tangent does not match the supplied E model"));
  if(matrank(pencil)!=3,error("E cone is not rank three"));
  T0=vector(4);T1=vector(4);
  for(i=1,4,my(c=cas_E_M_split(N,Prep,Emb,T[i]));T0[i]=c[1];T1[i]=c[2]);
  F=T0~*T0-17*T1~*T1;
  if(F==matrix(4,4),error("Pushout norm vanishes identically"));
  [NormPoint,Q,T,T0,T1,F,Emb];
}

{cas_E_pushout_ball(N,p,Push,P)=
  my(a=cas_linear_ball(N,p,Push[4],P),b=cas_linear_ball(N,p,Push[5],P),f,v);
  f=cas_ball_sub(N,p,cas_ball_mul(N,p,a,a),cas_ball_scale(N,p,17,cas_ball_mul(N,p,b,b)));
  v=cas_val(N,p,f[1]);
  if(f[2]<=v+2*nfeltval(N,2,p),error("Final pushout squareclass lacks sufficient certified precision"));
  [f,[v,f[2],f[2]-v-2*nfeltval(N,2,p)]];
}

{cas_E_q2_unitmod8(N,p,u)=
  for(r=1,7,if(r%2 && cas_val(N,p,u-r)>=3,return(r)));
  error("Q2 unit residue is not identified modulo 8");
}

{cas_E_q2_hilbert(N,p,a,b)=
  my(va,vb,ra,rb,e);
  if(p[3]!=1 || p[4]!=1,error("Expected the degree-one dyadic completion"));
  va=nfeltval(N,a,p);vb=nfeltval(N,b,p);
  ra=cas_E_q2_unitmod8(N,p,a/2^va);rb=cas_E_q2_unitmod8(N,p,b/2^vb);
  e=((ra-1)/2)*((rb-1)/2)+va*(rb^2-1)/8+vb*(ra^2-1)/8;
  (-1)^(e%2);
}

\\ Alternative to the degree-72 norm initializer: an exact point on this
\\ four-variable quadric over L produces the same M-conic witness.
{cas_E_basequadric_to_norm(N,MPrep,QPrep,P)=
  my(eta=QPrep[1],r=QPrep[2],h=QPrep[3],k=QPrep[4],Emb,PP,em,km,s,d,w0,den,v0,v1,m,y,n);
  if(#P!=4 || P==[0,0,0,0],error("A nonzero four-coordinate quadric point is required"));
  if(r^2-17*h^2!=eta || k!=2*h*(r+17*h),error("Base-quadric normalization fails"));
  if(P[1]^2-eta*P[2]^2-k*P[3]^2+17*eta*k*P[4]^2,error("Base quadric point exact identity fails"));
  Emb=cas_E_M_embedding(N,MPrep);s=Emb[2];em=MPrep[3];d=-MPrep[4];
  PP=vector(4,i,subst(lift(P[i]),'y,Emb[1]));km=subst(lift(k),'y,Emb[1]);
  w0=subst(lift(r),'y,Emb[1])+subst(lift(h),'y,Emb[1])*d;
  if(w0^2-em!=km*d,error("Base-quadric descent norm identity fails"));
  den=PP[3]^2-17*em*PP[4]^2;
  v0=PP[1]*PP[3]-em*PP[2]*s*PP[4];v1=PP[2]*PP[3]-PP[1]*s*PP[4];
  m=w0*v0-em*v1;y=km*den;n=v0-w0*v1;
  if(m==0 && y==0 && n==0,error("Degenerate base-quadric conversion"));
  if(m^2-d*y^2!=em*n^2,error("Base-quadric to M-norm identity fails"));
  [m,y,n];
}
