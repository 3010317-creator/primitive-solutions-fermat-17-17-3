\\ Local Cassels evaluation on the diagonal covering (a,a,1).
\\ Curve F: w^2=t(t-16)(t+1); tangent convention L2=z3-z0.
\\ Local approximations are certified by exact Hensel residual valuations.

{cas_ball_exact(v)=[v,1000000];}
{cas_val(N,p,v)=if(v==0,1000000,nfeltval(N,v,p));}
{cas_ball_add(N,p,A,B)=[A[1]+B[1],min(A[2],B[2])];}
{cas_ball_sub(N,p,A,B)=[A[1]-B[1],min(A[2],B[2])];}
{cas_ball_mul(N,p,A,B)=
  my(va=cas_val(N,p,A[1]),vb=cas_val(N,p,B[1]));
  [A[1]*B[1],min(min(A[2]+vb,B[2]+va),A[2]+B[2])];
}
{cas_ball_scale(N,p,c,A)=cas_ball_mul(N,p,cas_ball_exact(c),A);}

{cas_local_model(N,p,bits=160)=
  my(fs=factorpadic(N.pol,2,bits),fp);
  fp=0;
  for(i=1,matsize(fs)[1],if(poldegree(fs[i,1])==p[3]*p[4],fp=fs[i,1]));
  if(fp==0,error("Could not select local polynomial factor"));
  return(fp);
}
{cas_root_near1(N,p,h,fp,bits=160)=
  my(hp,z,zlift,err,der,vh,e=p[3]);
  vh=cas_val(N,p,h-1);
  if(vh<=2*e,error("Root is not in the Hensel near-one range"));
  hp=subst(lift(h),'y,Mod('y,fp))*(1+O(2^bits));
  z=Mod(1+O(2^bits),fp);
  \\ Inverse square root Newton avoids unstable polynomial Euclidean inversion
  \\ over approximate p-adic coefficients.  Starting at 1 selects the root
  \\ congruent to 1 modulo a power strictly greater than e.
  for(k=1,18,z=z*(3-hp*z^2)/2);
  z=hp*z;
  zlift=Mod(liftall(z),N.pol);
  err=cas_val(N,p,zlift^2-h);
  der=cas_val(N,p,2*zlift);
  if(err<=2*der,error("Hensel certificate failed"));
  if(cas_val(N,p,zlift-1)<=e,error("Wrong square root branch"));
  return([zlift,err-der]);
}

{cas_diagonal_local2_value(N,p,a,Q,bits=160,scale=3)=
  my(va=nfeltval(N,a,p),pi,c,u,d,fp,F,H,J,Rf,Rq,Rh,Rj,Ya,Yq,Mn,Bn,Z2n,Z3n,C2,N1,N2,term1,term2,term3,value,vvalue);
  if(va%2,error("Diagonal class has odd dyadic valuation"));
  pi=nfbasistoalg(N,p[2]);
  if(nfeltval(N,pi,p)!=1,error("The selected element is not a uniformizer"));
  c=scale/pi^(va/2);u=a*c^2;d=4*(u-1);
  if(nfeltval(N,u,p)!=0,error("The chord parameter is not a local unit"));
  if(d==0,error("Degenerate chord parameter"));
  fp=cas_local_model(N,p,bits);
  F=(1-4/u)*(1+4*u);
  H=-3*(1-4/u);
  J=5*(1+4*u);
  Rf=cas_root_near1(N,p,F,fp,bits);
  Rq=cas_root_near1(N,p,-15,fp,bits);
  Rh=cas_root_near1(N,p,H,fp,bits);
  Rj=cas_root_near1(N,p,J,fp,bits);
  Ya=cas_ball_scale(N,p,4*u,Rf);
  Yq=cas_ball_scale(N,p,4,Rq);
  Mn=cas_ball_sub(N,p,Ya,Yq);
  Bn=cas_ball_scale(N,p,4,cas_ball_sub(N,p,cas_ball_scale(N,p,u,Yq),Ya));
  Z2n=cas_ball_add(N,p,cas_ball_scale(N,p,16,Mn),Bn);
  Z3n=cas_ball_sub(N,p,Bn,Mn);
  C2=cas_ball_scale(N,p,4*a*c,Rh);
  term1=cas_ball_scale(N,p,a*Q[2],cas_ball_mul(N,p,Z2n,Rj));
  term2=cas_ball_scale(N,p,Q[1],cas_ball_mul(N,p,Z3n,C2));
  term3=cas_ball_scale(N,p,17*Q[3]*d,cas_ball_mul(N,p,C2,Rj));
  N1=cas_ball_add(N,p,cas_ball_sub(N,p,term1,term2),term3);
  N2=cas_ball_sub(N,p,Z3n,cas_ball_scale(N,p,d,Rj));
  value=cas_ball_mul(N,p,cas_ball_mul(N,p,N1,N2),C2);
  vvalue=cas_val(N,p,value[1]);
  if(value[2]<=vvalue+2*p[3],error("Insufficient precision or tangent value zero: increase bits/change scale"));
  print("CASSELS_LOCAL2_STABILITY=",[p[3],value[2],vvalue,value[2]-vvalue-2*p[3]]);
  return(value);
}
