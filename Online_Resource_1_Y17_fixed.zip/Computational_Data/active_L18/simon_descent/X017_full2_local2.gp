\\ Local squareclass and full 2-descent image on F: w^2=t(t-16)(t+1).
\\ No global bnf certification is performed here.
{x017_local2_data(N,p) =
  my(bid=idealstar(N,idealpow(N,p,2*p[3]+1),2),idx=List());
  for(i=1,#bid.cyc,if(bid.cyc[i]%2==0,listput(idx,i)));
  return([p,bid,Vec(idx)]);
}
{x017_local2_squareclass(N,D,a) =
  my(u,v,lg,res);
  if(a==0,error("Squareclass of zero requested"));
  v=nfeltval(N,a,D[1],&u);
  lg=ideallog(N,u,D[2]);
  res=vector(#D[3]+1);
  res[1]=v%2;
  for(i=1,#D[3],res[i+1]=lg[D[3][i]]%2);
  return(res);
}
{x017_local2_kummer(N,D,t) =
  if(t==0,return(concat(x017_local2_squareclass(N,D,-1),x017_local2_squareclass(N,D,-1))));
  if(t==16,return(concat(x017_local2_squareclass(N,D,1),x017_local2_squareclass(N,D,17))));
  if(t==-1,return(concat(x017_local2_squareclass(N,D,-1),x017_local2_squareclass(N,D,-17))));
  return(concat(x017_local2_squareclass(N,D,t),x017_local2_squareclass(N,D,t-16)));
}
{x017_local2_fullimage(N,p) =
  my(D=x017_local2_data(N,p),ts,img,t,u,rank_expected,m);
  if(p[4]!=1,error("This explicit unit construction assumes residue degree one"));
  ts=vector(#D[3]+1);
  ts[1]=4;
  for(i=1,#D[3],ts[i+1]=4*nfbasistoalg(N,D[2].gen[D[3][i]]));
  img=matrix(2*(#D[3]+1),#ts);
  for(j=1,#ts,
    t=ts[j];
    if(!nfislocalpower(N,p,t*(t-16)*(t+1),2),error("Explicit local x coordinate has nonsquare RHS"));
    img[,j]=x017_local2_kummer(N,D,t)~;
  );
  rank_expected=p[3]*p[4]+2;
  m=matrank(Mod(img,2));
  print("LOCAL_FULL2_IMAGE_AT_2=",[p[3],p[4],m,rank_expected]);
  if(m!=rank_expected,error("Local image basis is not complete"));
  return([D,img,ts]);
}
