default(nbthreads,1);
default(parisizemax,600000000);
run()={
 my(n=read("L18_nf_checkpoint.bin"),C=read("L18_factor_base_membership_certificate.bin"),W=read("L18_class_unit_exact_witness_single.bin"),b=read("L18_bnf_checkpoint.bin"),P,R,Q,e,a);
 if(nfcertify(n)!=[],error("Maximal order not certified"));
 if(C[1]!=n.pol || W[1]!=n.pol || W[2]!=n.zk || C[2]!=W[3],error("Field or ideal mismatch"));
 P=C[2];R=C[3];
 if(#R!=112 || #R!=#b[5],error("Factor base dimension mismatch"));
 for(i=1,#R,
   Q=R[i][1];e=R[i][2];a=R[i][3];
   if(Q!=b[5][i],error("Original factor-base ordering mismatch"));
   if(!isprime(Q[1]) || !setsearch(Set(idealprimedec(n,Q[1])),Q),error("Factor-base item is not the recorded prime ideal"));
   if(idealhnf(n,Q)!=idealmul(n,idealhnf(n,a),idealpow(n,P,e)),error("Exact factor-base ideal identity failed"));
 );
 print("ALL_112_FIXED_FACTOR_BASE_RELATIONS_VERIFIED=1");
 print("NO_BNF_CLASSGROUP_CORRECTNESS_ASSUMED=1");
};
iferr(run(),E,print("FIXED_FACTOR_BASE_FATAL=",E);quit(1));
quit;
