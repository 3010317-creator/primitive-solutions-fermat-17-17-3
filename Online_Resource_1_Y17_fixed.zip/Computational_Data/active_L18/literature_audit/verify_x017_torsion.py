"""Exact finite computations for X_0(17) over the 18-degree line field.
No CAS packages required. The field-theoretic argument is in the research notes.
"""
from fractions import Fraction as Q
from math import gcd

def points(p, ainv):
    a1,a2,a3,a4,a6=ainv
    return 1+sum((y*y+a1*x*y+a3*y-x*x*x-a2*x*x-a4*x-a6)%p==0
                 for x in range(p) for y in range(p))

E1=(3,0,2,0,0)
A=(1,-1,1,-1,-14)
counts=[]
for q in (11,13):
    ne=points(q,E1)
    trace=q+1-ne
    disc=(trace*trace-4*q)%17
    roots=[r for r in range(17) if r*r%17==disc]
    na=points(q,A)
    assert len(roots)==2
    counts.append(na)
    print(dict(q=q,trace_E1=trace,characteristic_discriminant_mod17=disc,
               square_roots=roots,number_A_Fq=na))
assert counts==[12,16]
assert gcd(*counts)==4
x,y=Q(7),Q(13)
a1,a2,a3,a4,a6=A
assert y*y+a1*x*y+a3*y == x**3+a2*x*x+a4*x+a6
lam=(3*x*x+2*a2*x+a4-a1*y)/(2*y+a1*x+a3)
nu=(-x**3+a4*x+2*a6-a3*y)/(2*y+a1*x+a3)
x2=lam*lam+a1*lam-a2-2*x
y2=-(lam+a1)*x2-nu-a3
assert (x2,y2)==(Q(11,4),Q(-15,8))
assert 2*y2+a1*x2+a3==0
print('2*(7,13) =',x2,y2,'is a nonzero point of order 2')
print('CERTIFICATE PASSED: X_0(17)(L)_tors = Z/4Z, provided L is the line field')
