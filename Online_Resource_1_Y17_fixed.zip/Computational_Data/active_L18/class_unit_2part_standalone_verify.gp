\\ Re-verify the exact 16-order ideal class and complete unit squareclasses.
\\ Only uses nf checkpoint plus exact witnesses, no bnf / GRH class-group data.
default(parisizemax,800000000);
run() = {
  my(n=read("L18_nf_checkpoint.bin"),C=read("L18_class_unit_exact_witness_single.bin"),P,al,U,W,M,beta,r,q,pr,mp,R,mat=matrix(11,0),found);
  if(nfcertify(n)!=[],error("Uncertified integral basis"));
  if(C[1]!=n.pol || C[2]!=n.zk,error("Field mismatch"));
  P=C[3]; al=C[4]; U=C[5]; W=C[6]; M=C[7];
  if(n.sign!=[2,8] || #U!=10 || #W!=11,error("Wrong unit dimensions"));
  if(idealhnf(n,al)!=idealhnf(n,idealpow(n,P,16)),error("P^16 principal identity failed"));
  for(i=1,#U,
    if(idealhnf(n,U[i])!=matid(18),error("Unit ideal failed"));
    if(abs(nfeltnorm(n,U[i]))!=1,error("Unit norm failed"));
  );
  beta=concat([al],U);
  for(i=1,#W,
    r=W[i];q=r[1];pr=0;found=0;
    for(j=1,#idealprimedec(n,q,1),
      my(z=idealprimedec(n,q,1)[j]);
      if(z[2]==r[2],pr=z;found=1;break);
    );
    if(!found,error("Character prime witness missing"));
    if(idealnorm(n,P)%q==0,error("Invalid residue prime for P"));
    mp=nfmodprinit(n,pr);
    R=vector(11,j,if(lift(nfmodpr(n,beta[j],mp)^((q-1)/2))==1,0,1));
    if(R!=r[3],error("Squareclass residue witness mismatch"));
    mat=concat(mat,R~);
  );
  if(matrank(Mod(mat,2))!=11,error("Character matrix not full rank"));
  if(mat!=M,error("Stored character matrix discrepancy"));
  print("EXACT_CLASS_GENERATOR_ORDER_16_VERIFIED=1");
  print("UNITS_MOD_SQUARES_EXHAUSTIVE_VERIFIED=1");
  print("NO_CLAIM_FULL_CLASS_GROUP_GENERATION=1");
};
iferr(run(),err,print("STANDALONE_CERT_FAILED=",err);quit(1));
quit;
