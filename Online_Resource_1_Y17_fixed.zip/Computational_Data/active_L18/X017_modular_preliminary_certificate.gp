default(nbthreads,1);
run()={
 my(Ea=ellinit([1,-1,0,12,8]),Eb=ellinit([1,-1,1,1,-1]));
 my(Es=ellinit([3,0,2,0,0]),Et=ellchangecurve(Es,[1,-1,-1,1]));
 if(ellglobalred(Ea)[1]!=54 || ellglobalred(Eb)[1]!=54,error("Conductor mismatch"));
 if(ellap(Ea,2)!=-1 || ellap(Eb,2)!=1,error("Local sign mismatch"));
 if(vector(5,i,Et[i])!=vector(5,i,Eb[i]),error("Reference curve isomorphism mismatch"));
 if(mfdim([18,2],1)!=0 || mfdim([54,2],0)!=2,error("Modular-space dimension mismatch"));
 if(ellap(Es,5)!=-3,error("Reference Frobenius trace mismatch"));
 print("MODULAR_PRELIMINARY_CERTIFICATE_PASSED");
 print("S2_LEVEL18_DIM=",mfdim([18,2],1));
 print("NEW_S2_LEVEL54_DIM=",mfdim([54,2],0));
 print("REFERENCE_INVARIANTS=",[Es.c4,Es.c6,Es.disc,Es.j]);
 print("LEVEL54_A2_A5=",[[ellap(Ea,2),ellap(Ea,5)],[ellap(Eb,2),ellap(Eb,5)]]);
};
iferr(run(),err,print("CERTIFICATE_FAILED ",err);quit(1));
quit;
