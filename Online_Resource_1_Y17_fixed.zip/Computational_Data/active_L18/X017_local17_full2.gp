\\ Exact local Kummer image for F: w^2=t(t-16)(t+1) at K=L_17.
\\ All group-theoretic completeness uses [K:Q_17] finite and 17 != 2.
{x017_local17_squareclass(N,pr,a)=
 my(pi=nfbasistoalg(N,pr[2]),v,u);
 if(a==0,error("squareclass requires nonzero input"));
 v=nfeltval(N,a,pr);u=nfmodpr(N,a/pi^v,pr);
 return([v%2,if(u^8==1,0,1)]);
}
{x017_local17_kummer(N,pr,t)=
 if(t==0,return(concat(x017_local17_squareclass(N,pr,-1),x017_local17_squareclass(N,pr,-1))));
 if(t==16,return(concat(x017_local17_squareclass(N,pr,1),x017_local17_squareclass(N,pr,17))));
 if(t==-1,return(concat(x017_local17_squareclass(N,pr,-1),x017_local17_squareclass(N,pr,-17))));
 return(concat(x017_local17_squareclass(N,pr,t),x017_local17_squareclass(N,pr,t-16)));
}
{x017_local17_image(N)=
 my(ps=idealprimedec(N,17),pr,pi,ts,rows);
 if(#ps!=1,error("Expected unique prime above17"));
 pr=ps[1];pi=nfbasistoalg(N,pr[2]);
 if(pr[3]!=18||pr[4]!=1||nfeltval(N,pi,pr)!=1,error("Unexpected ramification data"));
 ts=[4,16+pi];rows=matrix(2,4);
 for(i=1,2,if(!nfislocalpower(N,pr,ts[i]*(ts[i]-16)*(ts[i]+1),2),error("Local point witness failed"));rows[i,]=x017_local17_kummer(N,pr,ts[i]));
 if(rows!=[0,0,0,1;0,0,1,0],error("Unexpected image basis"));
 return(rows);
}
