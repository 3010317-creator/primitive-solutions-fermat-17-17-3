\\ Helpers for the Cassels pairing on diagonal classes (a,a,1) of
\\ F: w^2=t(t-16)(t+1).  Input a,b must have even valuation at EVERY finite prime.
\\ A conic witness Q=[r,s,h] must satisfy r^2-a*s^2=17*h^2 exactly.
\\ Fixed tangent convention throughout:
\\ L1=a*s*z2-r*z3+17*h*z0; L2=z3-z0.
\\ The local pairing is (L1(P)*L2(P),b).
\\ This module does not compute the dyadic contribution or certify any class group.

{x017_cassels_sqrtideal(N,a) =
  my(F=idealfactor(N,a), A=matid(poldegree(N.pol)));
  for(i=1,matsize(F)[1],
    if(F[i,2]%2,error("Cassels diagonal input has an odd finite valuation"));
    if(F[i,2],A=idealmul(N,A,idealpow(N,F[i,1],F[i,2]/2)));
  );
  if(idealhnf(N,idealmul(N,A,A))!=idealhnf(N,a),error("Ideal square-root check fails"));
  return(A);
}

{x017_cassels_conic_content(N,a,Q) =
  my(r=Q[1],s=Q[2],h=Q[3],A,C);
  if(r^2-a*s^2-17*h^2,error("Incorrect conic witness"));
  if(Q==[0,0,0],error("Zero conic witness"));
  A=x017_cassels_sqrtideal(N,a);
  C=idealadd(N,idealadd(N,r,h),idealmul(N,A,s));
  return([C,idealfactor(N,C)]);
}

\\ Evaluate all odd-prime contributions away from 17 without solving local covers.
\\ Return [sign, [[p,e,f,content_valuation,local_Hilbert_sign],...]].
{x017_cassels_odd_contribution(N,b,ContentData) =
  my(F=ContentData[2],ans=1,details=List(),pr,m,pi,hb);
  for(i=1,matsize(F)[1],
    pr=F[i,1];m=F[i,2];
    if(pr[1]==2 || pr[1]==17 || m%2==0,next);
    if(nfeltval(N,b,pr)%2,error("Second class has an odd valuation at odd support prime"));
    pi=nfbasistoalg(N,idealappr(N,pr));
    if(nfeltval(N,pi,pr)!=1,error("Uniformizer construction fails"));
    hb=nfhilbert(N,pi,b,pr);
    ans*=hb;
    listput(details,[pr[1],pr[3],pr[4],m,hb]);
  );
  return([ans,Vec(details)]);
}

\\ Exact real contribution for the same fixed tangent convention.
{x017_cassels_real_contribution(N,a,b,Q) =
  my(ans=1,details=List(),sa,sb,sq,v);
  if(Q[1]^2-a*Q[2]^2-17*Q[3]^2,error("Incorrect conic witness"));
  for(i=1,N.r1,
    sa=nfeltsign(N,a,i);sb=nfeltsign(N,b,i);
    if(sb>0,v=1,
      if(sa>0,sq=nfeltsign(N,Q[1],i),sq=nfeltsign(N,Q[3],i));
      if(!sq,error("Degenerate real conic witness"));
      v=-sq;
    );
    ans*=v;listput(details,[i,sa,sb,v]);
  );
  return([ans,Vec(details)]);
}
