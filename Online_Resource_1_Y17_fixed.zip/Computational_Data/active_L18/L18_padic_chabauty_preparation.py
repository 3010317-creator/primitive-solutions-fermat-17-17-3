"""Exact p-adic residue-disk sieve on X0(17)(L), p=5.
IMPORTANT: Global completeness is CONDITIONAL on rank(X0(17)(L))=1,
which this script does not prove. It uses separately certified 2- and5-saturation.
All computations are finite quotient-ring arithmetic modulo5^e.
"""
from fractions import Fraction
from pathlib import Path
from functools import lru_cache
import json
from flint import fmpz_mod_poly_ctx
rf=json.loads(Path('L18_small.json').read_text());fc=list(map(int,rf['coefficients_ascending']))
rp=json.loads(Path('X017_point_small_field.json').read_text());px=list(map(Fraction,rp['point_x_coefficients_ascending']));py=list(map(Fraction,rp['point_y_coefficients_ascending']))
rj=json.loads(Path('X017_jmap_and_fibre.json').read_text());Ac=rj['A_coefficients_descending'];Bc=rj['B_coefficients_descending']
rfin=json.loads(Path('L18_finite_group5_certificate.json').read_text());m=rfin['point_order']

class Ring:
 def __init__(self,e):
  self.e=e;self.mod=5**e;self.R=fmpz_mod_poly_ctx(self.mod);self.F=self.R(fc)
  self.R5=fmpz_mod_poly_ctx(5);self.F5=self.R5(fc)
  self.zero=self.R([0]);self.one=self.R([1])
  self.x=self.reduce_rat(px);self.y=self.reduce_rat(py)
  self.u=4*self.x-1;self.v=8*self.y+4*self.x+4
  self.A=-11;self.B=-890
  assert self.mul(self.v,self.v)==(self.pow(self.u,3)+self.A*self.u+self.B)
  u=self.u;v=self.v;A=self.A;B=self.B
  self.inv2v=self.inv(2*v);self.inv4v=self.inv(4*v)
  self.psi_cache={0:self.zero,1:self.one,2:2*v,
   3:3*self.pow(u,4)+6*A*self.pow(u,2)+12*B*u-A*A,
   4:self.mul(4*v,self.pow(u,6)+5*A*self.pow(u,4)+20*B*self.pow(u,3)-5*A*A*self.pow(u,2)-4*A*B*u-8*B*B-A**3)}
  self.tors=[None,(self.R([27]),self.R([136])),(self.R([10]),self.zero),(self.R([27]),self.R([-136]))]
 def mul(self,a,b):return a.mul_mod(b,self.F)
 def pow(self,a,k):return a.pow_mod(k,self.F)
 def inv(self,a):
  a5=self.R5([int(a[i])%5 for i in range(18)])
  assert not a5.is_zero(), 'Attempted inverse of nonunit'
  u5=a5.inverse_mod(self.F5);u=self.R([int(c) for c in u5.coeffs()]);prec=1
  while prec<self.e:
   u=self.mul(u,2-self.mul(a,u));prec*=2
  assert self.mul(a,u)==1
  return u
 def reduce_rat(self,cs):
  assert all(c.denominator%5 for c in cs)
  return self.R([c.numerator*pow(c.denominator,-1,self.mod)%self.mod for c in cs])
 def psi(self,n):
  if n<0:return -self.psi(-n)
  if n not in self.psi_cache:
   if n%2:
    h=(n-1)//2
    a=self.mul(self.psi(h+2),self.pow(self.psi(h),3));b=self.mul(self.psi(h-1),self.pow(self.psi(h+1),3))
    z=a-b
   else:
    h=n//2
    a=self.mul(self.psi(h+2),self.pow(self.psi(h-1),2));b=self.mul(self.psi(h-2),self.pow(self.psi(h+1),2))
    z=self.mul(self.mul(self.psi(h),a-b),self.inv2v)
   self.psi_cache[n]=z
  return self.psi_cache[n]
 def multiple(self,n):
  assert n>0
  pn=self.psi(n);invpn=self.inv(pn)
  phi=self.mul(self.u,self.pow(pn,2))-self.mul(self.psi(n-1),self.psi(n+1))
  omega=self.mul(self.mul(self.psi(n+2),self.pow(self.psi(n-1),2))-self.mul(self.psi(n-2),self.pow(self.psi(n+1),2)),self.inv4v)
  u=self.mul(phi,self.pow(invpn,2));v=self.mul(omega,self.pow(invpn,3))
  assert self.pow(v,2)==self.pow(u,3)+self.A*u+self.B
  return u,v
 def add_torsion(self,P,k):
  if not k:return P
  u,v=P;uu,vv=self.tors[k]
  lam=self.mul(vv-v,self.inv(uu-u));x=self.pow(lam,2)-u-uu;y=self.mul(lam,u-x)-v
  assert self.pow(y,2)==self.pow(x,3)+self.A*x+self.B
  return x,y
 def eval_desc(self,cs,x):
  z=self.zero
  for c in cs:z=self.mul(z,x)+c
  return z
 def j_multiple(self,n,k):
  u,v=self.add_torsion(self.multiple(n),k)
  x=(u+1)*pow(4,-1,self.mod);y=(v-u-5)*pow(8,-1,self.mod)
  j=self.mul(self.eval_desc(Ac,x)+self.mul(self.eval_desc(Bc,x),y),self.inv(self.pow(x-7,17)))
  return [int(j[i]) for i in range(18)]

Rings={}
def rr(e):
 if e not in Rings:Rings[e]=Ring(e)
 return Rings[e]

records=[]
for row in rfin['frobenius_conjugates']:
 rep=row['representations'][0];n=rep['n_mod_orderP'];k=rep['torsion_multiple'];steps=[];alive=True
 for e in range(2,6):
  R=rr(e);power=5**(e-1);stride=m*5**(e-2)
  j0=R.j_multiple(n,k);j1=R.j_multiple(n+stride,k)
  assert all(a%power==0 for a in j0[1:])
  assert all((b-a)%power==0 for a,b in zip(j0,j1))
  alpha=[a//power%5 for a in j0[1:]]
  beta=[((b-a)%R.mod)//power%5 for a,b in zip(j0[1:],j1[1:])]
  digits=[d for d in range(5) if all((a+d*b)%5==0 for a,b in zip(alpha,beta))]
  # Check a second finite difference; required linear behaviour at this precision.
  j2=R.j_multiple(n+2*stride,k)
  assert all((c-2*b+a)%R.mod==0 for a,b,c in zip(j0,j1,j2))
  step={'modulus':R.mod,'n_base':n,'torsion_multiple':k,'stride':stride,
   'alpha_nonconstant_divided':alpha,'beta_nonconstant_divided':beta,
   'digits_surviving':digits,'derivative_nonzero':any(beta)}
  steps.append(step)
  if not digits:alive=False;break
  assert len(digits)==1,'Multiple branches require expansion; not silently discarded'
  n+=digits[0]*stride
 record={'frobenius_power':row['frobenius_power'],'initial_n':rep['n_mod_orderP'],
 'torsion_multiple':k,'steps':steps,'survives_tested_precision':alive,'last_n':n}
 records.append(record)
 print('Frob',row['frobenius_power'],'survives',alive,'steps',[(s['modulus'],s['digits_surviving']) for s in steps],flush=True)

out={'assumption':'rank X0(17)(L)=1 REQUIRED for global closure completeness; not established by this computation.',
 'prime':5,'P_order_mod5':m,'disks':records,
 'surviving_disks':[r['frobenius_power'] for r in records if r['survives_tested_precision']],
 'scope':'Exact local quotient-ring obstructions and derivative residues only. No unconditional global classification is asserted.'}
Path('L18_padic_disk_sieve.json').write_text(json.dumps(out,indent=2)+'\n')
print('Surviving disks:',out['surviving_disks'],flush=True)
