"""Independent FLINT verification of the last global conic and its tangent.

GP is used only to export already saved exact algebraic numbers.  All asserted
identities, including the embedding of L into M, are recomputed in FLINT.
"""
from __future__ import annotations

import argparse
import json
import os
from pathlib import Path
import subprocess

from flint import fmpq, fmpq_poly as QP


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("witness", nargs="?", default="simon_descent/Cassels_E_lowdisc_eta_norm_witness_from_base.bin")
    parser.add_argument("--replay-json", help="Use portable coefficient data; GP is never invoked.")
    parser.add_argument("--export-json", default="simon_descent/Cassels_E_final_exact_data.json")
    parser.add_argument(
        "--prep", default="simon_descent/Cassels_E_conic_M17_lowdisc_preparation.bin"
    )
    parser.add_argument(
        "--lift", default="simon_descent/Cassels_higher_lowdisc_second_lift.bin"
    )
    parser.add_argument(
        "--output", default="simon_descent/Cassels_E_final_conic_flint_certificate.json"
    )
    parser.add_argument(
        "--base-point", default="simon_descent/Cassels_E_base_quadric_lowdisc_point.bin"
    )
    parser.add_argument(
        "--base-prep", default="simon_descent/Cassels_E_base_quadric_lowdisc_soluble.bin"
    )
    args = parser.parse_args()
    if args.replay_json:
        packed = json.loads(Path(args.replay_json).read_text())
        if packed.get("schema") != "x017-final-conic-exact-v1":
            raise ValueError("Unexpected portable coefficient schema")
        data = packed["data"]
        for key, value in packed["sources"].items():
            setattr(args, key, value)
    else:
        for name in (args.witness, args.prep, args.lift, args.base_point, args.base_prep):
            if not Path(name).is_file():
                raise FileNotFoundError(name)
        gp = Path("local_cas/pari-gmp/Olinux-x86_64/gp-dyn").resolve()
        code = f"""
    default(nbthreads,1);
    default(parisizemax,1200000000);
    allocatemem(134217728);
    N=read("L18_nf_checkpoint.bin");
    P=read({json.dumps(args.prep)});
    H=read({json.dumps(args.lift)});
    W=read({json.dumps(args.witness)});
    BP=read({json.dumps(args.base_point)});
    BD=read({json.dumps(args.base_prep)});
    m=poldegree(P[1].pol);n=poldegree(N.pol);
    cv(z,d)=vector(d,i,Str(polcoef(lift(z),i-1,'y)));
    print([cv(N.pol,n+1),cv(H[11],n),cv(P[1].pol,m+1),cv(P[2],m),cv(P[3],m),cv(P[4],m),cv(subst(lift(P[6]),'x,'y),m),vector(3,i,cv(W[i],m)),vector(2,k,vector(4,i,vector(4,j,cv(H[12][k][i,j],n)))),vector(4,i,cv(BP[i],n)),vector(4,i,cv(BD[i],n))]);
    quit;
    """
        env = os.environ.copy()
        env["LD_LIBRARY_PATH"] = str(Path("pydeps/python_flint.libs").resolve())
        proc = subprocess.run(
            [str(gp), "-q", "-f"], input=code, text=True, capture_output=True, env=env
        )
        if proc.returncode:
            raise RuntimeError(proc.stderr)
        if not proc.stdout.strip():
            raise RuntimeError("GP data export produced no JSON: " + proc.stderr)
        data = json.loads(proc.stdout.strip())
        packed = {"schema": "x017-final-conic-exact-v1",
                  "description": "All polynomial coefficient arrays are ascending and contain exact rational strings.",
                  "data_layout": ["L_polynomial", "eta_L", "M_polynomial", "sqrt17_M", "eta_M", "lambda_M", "L_generator_in_M", "M_norm_point_3coords", "E_two_4x4_matrices_over_L", "L_quadric_point_4coords", "L_quadric_parameters_eta_r_h_k"],
                  "sources": {key: getattr(args, key) for key in ("witness", "prep", "lift", "base_point", "base_prep")},
                  "data": data}
        Path(args.export_json).write_text(json.dumps(packed, indent=2) + "\n")
    lp, eta_l, mp, s, eta, lam, emb = [
        QP([fmpq(v) for v in a]) for a in data[:7]
    ]
    w = [QP([fmpq(v) for v in a]) for a in data[7]]
    em_l = [
        [[QP([fmpq(v) for v in a]) for a in row] for row in mat]
        for mat in data[8]
    ]

    def mul(a: QP, b: QP) -> QP:
        return (a * b) % mp

    def inv(a: QP) -> QP:
        g, u, _ = a.xgcd(mp)
        assert g.degree() == 0 and g[0] != 0
        return (u / g[0]) % mp

    def div(a: QP, b: QP) -> QP:
        return mul(a, inv(b))

    def evaluate(a: QP) -> QP:
        ans = QP([])
        for i in range(a.degree(), -1, -1):
            ans = mul(ans, emb) + a[i]
        return ans % mp

    zero, one = QP([]), QP([1])
    assert lp.degree() == 18 and mp.degree() == 36
    assert evaluate(lp) == 0
    assert evaluate(eta_l) == eta % mp
    assert mul(s, s) == 17
    assert (lam + 17 - 4 * s) % mp == 0
    x, y, z = w
    assert any(a != 0 for a in w)
    assert (mul(x, x) + mul(lam, mul(y, y)) - mul(eta, mul(z, z))) % mp == 0

    bp = [QP([fmpq(v) for v in row]) for row in data[9]]
    bd = [QP([fmpq(v) for v in row]) for row in data[10]]
    a_l, r_l, h_l, k_l = bd
    assert a_l == eta_l
    assert (r_l*r_l - 17*h_l*h_l - a_l) % lp == 0
    assert (k_l - 2*h_l*(r_l + 17*h_l)) % lp == 0
    bx, by, bz, bw = bp
    assert any(v != 0 for v in bp)
    assert (bx*bx-a_l*by*by-k_l*bz*bz+17*a_l*k_l*bw*bw) % lp == 0
    bx, by, bz, bw = map(evaluate, bp)
    k_m = evaluate(k_l)
    w0 = (evaluate(r_l) - mul(evaluate(h_l), lam)) % mp
    den = (mul(bz,bz) - 17*mul(eta,mul(bw,bw))) % mp
    vv0 = (mul(bx,bz) - mul(eta,mul(by,mul(s,bw)))) % mp
    vv1 = (mul(by,bz) - mul(bx,mul(s,bw))) % mp
    expected_w = [
        (mul(w0,vv0)-mul(eta,vv1)) % mp,
        mul(k_m,den),
        (vv0-mul(w0,vv1)) % mp,
    ]
    assert expected_w == w

    u0, v0 = (3 * s - 17) / 2, -(5 * s + 13) / 2
    constant = -4 * (34 - lam)
    assert (mul(u0, u0) + mul(lam, mul(v0, v0)) - constant) % mp == 0
    u = (mul(u0, x) + mul(lam, mul(v0, y))) % mp
    v = (mul(v0, x) - mul(u0, y)) % mp
    zq = mul(eta, z)
    theta, psi = div(u + v / 2, 34 - lam), v / 68
    q = [zero, zq, theta, psi]
    cone = (
        4 * mul(zq, zq)
        + mul(eta, mul(34 - lam, mul(theta, theta)))
        - 68 * mul(eta, mul(theta, psi))
        + 68 * mul(eta, mul(lam, mul(psi, psi)))
    ) % mp
    assert cone == 0
    em = [[[evaluate(a) for a in row] for row in mat] for mat in em_l]
    pencil = [
        [(mul(lam, em[0][i][j]) + em[1][i][j]) % mp for j in range(4)]
        for i in range(4)
    ]
    tangent = [
        -2 * mul(lam, zq),
        4 * zq,
        mul(eta, mul(34 - lam, theta) - 34 * psi),
        mul(eta, -34 * theta + 68 * mul(lam, psi)),
    ]
    pq = [sum((mul(pencil[i][j], q[j]) for j in range(4)), zero) % mp for i in range(4)]
    assert all((pq[i] / 2 - tangent[i]) % mp == 0 for i in range(4))
    assert sum((mul(q[i], pq[i]) for i in range(4)), zero) % mp == 0
    assert any(a != 0 for a in tangent)

    report = {
        "witness_file": args.witness,
        "prep_file": args.prep,
        "lift_file": args.lift,
        "verifier": "python-flint fmpq_poly; exact rational coefficient inputs",
        "input_mode": "portable JSON without GP" if args.replay_json else "GP export saved to portable JSON",
        "portable_data_file": args.replay_json or args.export_json,
        "field_degrees": [lp.degree(), mp.degree()],
        "base_field_embedding": True,
        "eta_embedding": True,
        "sqrt17_identity": True,
        "lambda_identity": True,
        "nonzero_norm_eta_point": True,
        "base_norm17_identity": True,
        "base_quadric_normalization": True,
        "nonzero_base_quadric_point": True,
        "base_quadric_to_M_norm_map": True,
        "constant_norm_point": True,
        "final_conic_point": True,
        "tangent_matches_supplied_E_pencil": True,
        "tangent_nonzero": True,
        "maximum_witness_coefficient_string_length": max(len(v) for row in data[7] for v in row),
    }
    Path(args.output).write_text(json.dumps(report, indent=2) + "\n")
    print(json.dumps(report, indent=2))


if __name__ == "__main__":
    main()
