\\ Independent exact small-level calculations for the BVY reduction.
default(nbthreads,1);
{
CurveB=ellinit([1,-1,1,1,-1]);
CurveA=ellinit([1,-1,0,12,8]);
if(ellglobalred(CurveA)[1]!=54 || ellglobalred(CurveB)[1]!=54,error("Conductor calculation"));
if(CurveA.disc!=-2^3*3^9 || CurveB.disc!=-2^3*3^3,error("Minimal discriminants"));
if(ellap(CurveA,2)!=-1 || ellap(CurveB,2)!=1,error("Multiplicative splitting at two"));
if(mfdim([18,2],0)!=0 || mfdim([54,2],0)!=2,error("Small-level newspace dimensions"));
print("MODULAR_SMALL_LEVELS=",[18,0,54,2]);
print("CURVES_A_B=",[CurveA[1..5],CurveB[1..5]]);
print("CONDUCTOR_DISCRIMINANT_A2=",[[54,CurveA.disc,-1],[54,CurveB.disc,1]]);
print("Q_COEFFICIENTS_THROUGH_18=",[ellan(CurveA,18),ellan(CurveB,18)]);
print("MODULAR_LEVEL18_54_CURVES_EXACT_AUDIT_OK");
}
quit;
