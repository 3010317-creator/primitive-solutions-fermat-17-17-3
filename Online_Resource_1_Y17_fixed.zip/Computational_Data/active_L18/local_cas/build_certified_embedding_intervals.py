"""Certify dyadic embedding boxes using FLINT's complex root isolation.

The isolated balls cover every root of the exact defining polynomial. The
field signature (2,8) is independently certified by PARI nfcertify. Therefore
the two balls crossing the real line contain the real roots, while the eight
upper-half-plane balls select one root from each conjugate pair.
"""
from pathlib import Path
import hashlib,json
from flint import acb_poly,arb,ctx

root=Path(__file__).resolve().parent
source=root/'L18_integral_basis.json'
coeff,den,basis=json.loads(source.read_text())
ctx.prec=384
roots=acb_poly(coeff).roots(tol=arb('1e-65'),maxprec=1536)
assert len(roots)==18
real=[z for z in roots if z.imag.contains(0)]
positive=[z for z in roots if z.imag>0]
negative=[z for z in roots if z.imag<0]
assert (len(real),len(positive),len(negative))==(2,8,8)
selected=sorted(real,key=lambda z:float(z.real))+sorted(positive,key=lambda z:(float(z.real),float(z.imag)))
scale=1<<48
def bounds(x):
    lo=(x*scale).lower().floor().unique_fmpz()
    hi=(x*scale).upper().ceil().unique_fmpz()
    assert lo is not None and hi is not None
    lo,hi=int(lo),int(hi)
    assert arb(lo)/scale<=x.lower() and arb(hi)/scale>=x.upper()
    assert abs(lo)<1<<60 and abs(hi)<1<<60
    return [lo,hi]
matrix=[]
for z in selected:
    row=[]
    for p in basis:
        v=acb_poly(p)(z)/den
        row.append([bounds(v.real),bounds(v.imag)])
    matrix.append(row)
data=dict(polynomial=coeff,integral_basis_denominator=den,integral_basis=basis,
    source_sha256=hashlib.sha256(source.read_bytes()).hexdigest(),
    signature=[2,8],precision=ctx.prec,scale_bits=48,
    isolated_roots=[dict(real=str(z.real),imag=str(z.imag)) for z in roots],
    embedding_intervals=matrix)
dest=root/'L18_certified_embedding_intervals.json'
dest.write_text(json.dumps(data,indent=2)+'\n')
flat=[]
for row in matrix:
    flat.append('{'+','.join('{'+','.join(str(x) for pair in v for x in pair)+'}' for v in row)+'}')
(root/'L18_certified_embedding_intervals.h').write_text(
    '/* Generated from independently isolated FLINT root balls. Scale=2^48. */\n'
    'static const long x17_embedding_bounds[10][18][4] = {\n'+',\n'.join(flat)+'\n};\n')
print(json.dumps(dict(certified_embedding_rows=len(matrix),basis_vectors=18,
    scale_bits=48,max_entry=max(abs(x) for row in matrix for v in row for pair in v for x in pair),
    certificate_sha256=hashlib.sha256(dest.read_bytes()).hexdigest())))
