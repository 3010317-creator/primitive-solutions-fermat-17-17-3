Computational data for The equation X^3 - Y^17 = 2

See ../Supplementary_Data_Guide.txt for the file-to-section index, software requirements and commands. The expanded factor-base cache is included in this edition.
