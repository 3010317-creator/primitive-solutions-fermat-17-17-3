\\ Run from this directory. This rebuilds the field from the text witness.
\\ It uses neither a binary nf checkpoint nor any bnf class-group data.
default(nbthreads,1);
default(parisizemax,800000000);
read("different_exact_witness.gp");
run()={
 my(C=DIFFERENT_CERTIFICATE,n,delta);
 if(!polisirreducible(C[1]),error("Reducible field polynomial"));
 n=nfinit(C[1]);
 if(nfcertify(n)!=[],error("Uncertified maximal order"));
 if(n.disc!=2^16*3^20*17^17 || n.sign!=[2,8],error("Field invariants mismatch"));
 delta=sum(i=1,18,C[8][i]*C[2][i]);
 if(idealhnf(n,delta)!=idealhnf(n,n.diff),error("Principal different identity fails"));
 if(abs(nfeltnorm(n,delta))!=n.disc,error("Different norm fails"));
 print("PRINCIPAL_DIFFERENT_REBUILT_FROM_TEXT_WITH_FRESH_NFINIT=1");
};
iferr(run(),E,print("DIFFERENT_TEXT_CERTIFICATE_FAILED ",E);quit(1));
quit;
