default(nbthreads,1);
default(parisizemax,500000000);
run()={
 my(root="/workspace/scratch/4094a4d93451/active_L18/",b,n,V,W,H);
 b=read(concat(root,"L18_bnf_checkpoint.bin"));n=b.nf;
 if(nfcertify(n)!=[],error("Uncertified maximal order"));
 V=read(concat(root,"class_certification/factor_base_50000.bin"));
 W=List(b[5]);
 forprime(p=2,50000,
  my(ps=idealprimedec(n,p));
  for(j=1,#ps,if(idealnorm(n,ps[j])<=50000,listput(W,ps[j])));
 );
 W=Set(Vec(W));
 if(Set(V)!=W,error("Expanded factor base differs from full regenerated prime set"));
 H=vector(#V,j,idealhnf(n,V[j]));
 if(#Set(H)!=#V,error("Duplicated expanded prime ideals"));
 if(#setminus(Set(b[5]),Set(V)),error("Original factor base missing"));
 if(#V!=5068,error("Wrong expanded dimension"));
 print("EXPANDED_FACTOR_BASE_EXACTLY_REGENERATED_HNF_UNIQUE=",#V);
 print("EXPANDED_CLASS_MEMBERSHIP_FOLLOWS_FROM_STRICT_PREFIX=1");
};
iferr(run(),E,print("EXPANDED_BASE_AUDIT_FAILED ",E);quit(1));
quit;
