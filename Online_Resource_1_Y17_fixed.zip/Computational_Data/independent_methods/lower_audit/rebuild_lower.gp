default(nbthreads,1);
default(realprecision,120);
default(parisizemax,1800000000);
allocatemem(134217728);
read("simon_descent/Cassels_higher_local.gp");
read("simon_descent/X017_full2_local2.gp");
read("simon_descent/Cassels_hilbert_q2.gp");
read("X017_cassels_diagonal_support.gp");

\\ Explicit quadratic norms span the local norm subgroup.  No global
\\ reciprocity table is used to decide any large-dyadic Hilbert character.
{audit_norm_character(N,D,b,seed)=
  my(p=D[1],n=#D[3]+1,pi,scale,bb,cut,Basis=matrix(n,0),Witness=List(),z,q,v,tmp,r,H);
  if(x017_local2_squareclass(N,D,b)==vector(n),return([vectorv(n),Basis,[]]));
  setrand(seed);pi=nfbasistoalg(N,p[2]);
  scale=pi^floor(nfeltval(N,b,p)/2);bb=b/scale^2;
  cut=idealpow(N,p,2*p[3]+3);
  v=x017_local2_squareclass(N,D,-bb)~;
  if(v!=vectorv(n),Basis=Mat(v);listput(Witness,[0,1/scale,-bb]));
  for(j=1,10000,
    if(j<=2*p[3]+1,z=pi^(j-1),
      r=nfbasistoalg(N,vectorv(poldegree(N.pol),i,random(8)));
      z=pi^random(p[3]+1)*(1+pi*r));
    z=nfbasistoalg(N,nfeltreduce(N,z,cut));q=1-bb*z^2;if(q==0,next);
    v=x017_local2_squareclass(N,D,q)~;tmp=matconcat([Basis,Mat(v)]);
    if(matrank(Mod(tmp,2))>matsize(Basis)[2],Basis=tmp;listput(Witness,[1,z/scale,q]));
    if(matsize(Basis)[2]==n-1,
      H=lift(matker(Mod(Basis~,2)));
      if(matsize(H)[2]!=1,error("Norm span is not codimension one"));
      for(k=1,#Witness,if(Witness[k][1]^2-b*Witness[k][2]^2!=Witness[k][3],error("False exact norm witness")));
      return([H[,1],Basis,Vec(Witness)]));
  );error("Unable to span norm hyperplane");
}

{audit_all()=
  my(N=read("L18_nf_checkpoint.bin"),A=read("simon_descent/provisional_diagonal11.bin"),LD=read("simon_descent/full2_local2_images.bin"),OldH=read("simon_descent/Cassels_hilbert_characters_big2.bin"),OldRows=read("simon_descent/Cassels_local2_all_rows.bin"),OldM=read("simon_descent/Cassels_pairing_diagonal11.bin"),n=#A,H,NormData,Rows=vector(n),M=matrix(n,n),Factors=vector(n),p,Q,V,cls,P,L,f,eq,one,tsq,q2,odd,real,content,aux,hs,Pr17);
  if(LD[1][1][1][3]!=17||LD[2][1][1][3]!=1,error("Dyadic ordering differs"));
  H=matrix(19,n);NormData=vector(n);
  for(j=1,n,
    NormData[j]=audit_norm_character(N,LD[1][1],A[j],26001102+101*j);
    H[,j]=NormData[j][1];
    if(H[,j]!=OldH[5][,j],error("Norm-generated character differs from reciprocity table"));
    print("INDEPENDENT_NORM_CHARACTER=",[j,matsize(NormData[j][2])[2],H[,j]~]);
  );
  Pr17=idealprimedec(N,17);
  for(j=1,n,
    x017_cassels_sqrtideal(N,A[j]);
    for(k=1,#Pr17,if(!nfislocalpower(N,Pr17[k],A[j],2),error("A diagonal class is nonsquare at17")));
  );
  for(i=1,n,
    Q=read(Str("simon_descent/Cassels_conic_a",i,".bin"));
    if(Q==[0,0,0]||Q[1]^2-A[i]*Q[2]^2-17*Q[3]^2,error("Conic witness fails"));
    V=vector(2);cls=vector(2);tsq=vector(2);
    for(k=1,2,
      p=LD[k][1][1];
      V[k]=cas_diagonal_local2_value(N,p,A[i],Q,96,3);
      cls[k]=x017_local2_squareclass(N,LD[k][1],V[k][1]);
      if(cls[k]!=OldRows[i][2][k],error("Recomputed tangent squareclass differs"));
      P=cas_diagonal_point2(N,p,A[i],Q,96,3,1);
      one=cas_ball_exact(1);
      eq=[cas_ball_sub(N,p,cas_ball_sub(N,p,cas_ball_mul(N,p,P[4],P[4]),cas_ball_scale(N,p,A[i],cas_ball_mul(N,p,P[2],P[2]))),one),
          cas_ball_add(N,p,cas_ball_sub(N,p,cas_ball_scale(N,p,A[i],cas_ball_mul(N,p,P[3],P[3])),cas_ball_mul(N,p,P[4],P[4])),cas_ball_exact(17))];
      for(j=1,2,if(cas_val(N,p,eq[j][1])<eq[j][2],error("Constructed cover point fails an equation")));
      L=cas_diagonal_tangents(N,p,A[i],Q,P);f=cas_ball_mul(N,p,L[1],L[2]);
      if(f[2]<=cas_val(N,p,f[1])+2*p[3],error("Actual tangent product has unstable squareclass"));
      if(x017_local2_squareclass(N,LD[k][1],f[1])!=cls[k],error("Denominator-cleared and direct tangent products disagree"));
      tsq[k]=[P,eq,f];
    );
    content=x017_cassels_conic_content(N,A[i],Q);
    odd=vector(n,j,x017_cassels_odd_contribution(N,A[j],content)[1]);
    real=vector(n,j,x017_cassels_real_contribution(N,A[i],A[j],Q)[1]);
    aux=read(Str("simon_descent/Cassels_aux_row_a",i,".bin"));
    if(content!=aux[1]||odd!=aux[2]||real!=aux[3],error("Fresh odd/real data differs"));
    q2=vector(n,j,x017_q2_hilbert(N,LD[2][1][1],V[2][1],A[j]));
    for(j=1,n,
      hs=(-1)^lift(Mod(cls[1]*H[,j],2))*q2[j]*odd[j]*real[j];
      M[i,j]=(1-hs)/2;
    );
    if(M[i,]!=OldM[1][i,],error("Rebuilt lower pairing row differs"));
    Rows[i]=[V,cls,tsq];Factors[i]=[content,odd,real,q2];
    print("LOWER_PAIRING_REBUILT_ROW=",[i,M[i,]]);
  );
  if(M!=M~||vector(n,i,M[i,i])!=vector(n)||matrank(Mod(M,2))!=6,error("Pairing algebra fails"));
  writebin("/workspace/scratch/4094a4d93451/independent_methods/lower_audit/lower_independent_rebuild.bin",[H,NormData,Rows,Factors,M]);
  print("LOWER_PAIRING_INDEPENDENT_REBUILD_OK_RANK6");
}
iferr(audit_all(),E,print("LOWER_AUDIT_ERROR=",E);quit(1));
quit;
