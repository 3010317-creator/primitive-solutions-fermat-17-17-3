\\ Independent odd-place audit by actual smooth finite-field cover points.
\\ Nonzero normalized tangent values prove exact valuations after Hensel lifting.
read("X017_cassels_diagonal_support.gp");
default(parisizemax,2000000000);
{x017_odd_cover_witness(N,a,Q,pr,m) =
  my(mp=nfmodprinit(N,pr,'z),af=nfmodpr(N,a,mp),pi,cf,fg,xx,zs,l1,l2,found=0,sg2,sg3);
  if(nfeltval(N,a,pr)!=0,error("This audit expects a local unit"));
  pi=nfbasistoalg(N,idealappr(N,pr));
  cf=vector(3,j,nfmodpr(N,Q[j]/pi^m,mp));
  fg=ffgen(af);
  for(c=1,5000,
    xx=fg+c;
    if(xx==0 || xx==16 || xx==-1,next);
    if(!issquare(xx/af) || !issquare((xx-16)/af) || !issquare(xx+1),next);
    zs=[sqrt(xx/af),sqrt((xx-16)/af),sqrt(xx+1)];
    for(sg2=0,1,for(sg3=0,1,
      l1=af*cf[2]*((-1)^sg2*zs[2])-cf[1]*((-1)^sg3*zs[3])+17*cf[3];
      l2=(-1)^sg3*zs[3]-1;
      if(l1!=0 && l2!=0,
        zs[2]*=(-1)^sg2;zs[3]*=(-1)^sg3;
        found=1;break(3);
      );
    ));
  );
  if(!found,error("Failed to find a smooth cover point away from tangents"));
  if(af*zs[2]^2-zs[3]^2+17 || zs[3]^2-af*zs[1]^2-1 || af*zs[1]^2-af*zs[2]^2-16,error("Finite cover point is invalid"));
  if(prod(j=1,3,zs[j])==0,error("Square-root Hensel derivatives are not units"));
  return([mp,xx,zs,l1,l2]);
}
{
N=read("L18_nf_checkpoint.bin");
D=read("simon_descent/provisional_diagonal11.bin");
AllWitnesses=List();
for(i=1,#D,
  a=D[i];Q=read(Str("simon_descent/Cassels_conic_a",i,".bin"));
  AUX=read(Str("simon_descent/Cassels_aux_row_a",i,".bin"));
  F=AUX[1][2];ActualOdd=vector(#D,j,1);Count=0;
  for(k=1,matsize(F)[1],
    pr=F[k,1];m=F[k,2];
    if(pr[1]==2 || pr[1]==17,next);
    W=x017_odd_cover_witness(N,a,Q,pr,m);
    q=pr[1]^pr[4];
    for(j=1,#D,
      if(nfeltval(N,D[j],pr)!=0,error("Second class is not a unit in finite audit"));
      bf=nfmodpr(N,D[j],W[1]);
      ch=if(bf^((q-1)/2)==1,1,-1);
      ActualOdd[j]*=ch^(m%2);
    );
    listput(AllWitnesses,[i,pr,m,W[2],W[3],W[4],W[5]]);
    Count++;
  );
  if(ActualOdd!=AUX[2],error("Finite-field pairing disagrees with ideal/Hilbert support formula"));
  print("FINITE_ODD_ROW_AUDIT=",[i,Count,ActualOdd]);
);
writebin("/workspace/scratch/4094a4d93451/independent_methods/lower_audit/odd_witnesses.bin",Vec(AllWitnesses));
print("ALL_FINITE_ODD_PAIRING_ROWS_AUDITED=",#AllWitnesses);
}
quit;
