"""Independent mod-25 j test using affine binary group arithmetic.
No division polynomials or inherited arithmetic implementation are used.
"""
from pathlib import Path
from fractions import Fraction
from flint import fmpz_mod_poly_ctx
import json
fc=json.loads(Path('L18_small.json').read_text())['coefficients_ascending'];R=fmpz_mod_poly_ctx(25);F=R(fc);R5=fmpz_mod_poly_ctx(5);F5=R5(fc)
def m(a,b):return (a*b)%F
def inv(a):
 a5=R5([int(c)%5 for c in a.coeffs()]);assert a5!=0
 b5=a5.inverse_mod(F5);b=R([int(c) for c in b5.coeffs()]);b=m(b,2-m(a,b));assert m(a,b)==1
 return b

def red(cs):
 cs=[Fraction(c) for c in cs];assert all(c.denominator%5 for c in cs)
 return R([c.numerator*pow(c.denominator,-1,25)%25 for c in cs])
def short_from_file(path):
 r=json.loads(Path(path).read_text());x=red(r['point_x_coefficients_ascending']);y=red(r['point_y_coefficients_ascending'])
 return 4*x-1,8*y+4*x+4

def valid(P):
 if P is None:return True
 u,v=P;return m(v,v)==m(m(u,u),u)-11*u-890

def add(P,Q):
 if P is None:return Q
 if Q is None:return P
 u,v=P;uu,vv=Q
 if u==uu:
  if v+vv==0:return None
  assert v==vv
  lam=m(3*m(u,u)-11,inv(2*v))
 else:lam=m(vv-v,inv(uu-u))
 x=m(lam,lam)-u-uu;y=m(lam,u-x)-v
 return x,y

def mul(P,n):
 out=None
 while n:
  if n&1:out=add(out,P)
  n//=2
  if n:P=add(P,P)
 return out

P=short_from_file('X017_point_small_field.json');T=(R([27]),R([136]));Tor=[None,T,(R([10]),R([0])),(R([27]),R([-136]))]
assert valid(P) and all(valid(Q) for Q in Tor)
jr=json.loads(Path('X017_jmap_and_fibre.json').read_text())
def ev(cs,x):
 z=R([0])
 for c in cs:z=m(z,x)+c
 return z

def jval(P):
 assert P is not None and valid(P)
 u,v=P;x=(u+1)*19;y=(v-u-5)*22
 D=(x-7).pow_mod(17,F)
 j=m(ev(jr['A_coefficients_descending'],x)+m(ev(jr['B_coefficients_descending'],x),y),inv(D))
 return [int(j[i]) for i in range(18)]

fin=json.loads(Path('L18_finite_group5_certificate.json').read_text());order=fin['point_order'];rows=[];rational=[]
for c in fin['frobenius_conjugates']:
 rep=c['representations'][0];n=rep['n_mod_orderP'];k=rep['torsion_multiple'];assert n%2==1
 for a in range(5):
  Q=add(mul(P,n+a*order),Tor[k]);js=jval(Q)
  row={'frob':c['frobenius_power'],'a':a,'n':n+a*order,'k':k,'j_coefficients_mod25':js}
  rows.append(row)
  if not any(js[1:]):rational.append({'frob':c['frobenius_power'],'a':a,'constant':js[0]})
assert rational==[{'frob':0,'a':0,'constant':17}]
other=[]
for num in [2,3]:
 pp=short_from_file('X017_P'+str(num)+'_small_field.json');js=jval(pp);assert not any(js[1:])
 other.append({'point':'P'+str(num),'j_mod25':js[0]})
assert other==[{'point':'P2','j_mod25':12},{'point':'P3','j_mod25':2}]
out={'method':'Exact affine binary group arithmetic over (Z/25Z)[t]/F, independent of division-polynomial implementation.','rows':rows,'rational_cases':rational,'additional_point_checks':other,'scope':'Finite quotient-ring check; global uses require the separate saturation/rank arguments.'}
Path('X017_independent_mod25_binary_certificate.json').write_text(json.dumps(out,indent=2)+'\n')
print('90 local candidates checked. Rational residue cases:',rational)
print('Additional point values:',other)
print('CERTIFICATE PASSED')
