"""Finite-field groundwork over F_(5^18), with no global rank assumption."""
from flint import fq_default_ctx,fmpz_mod_poly_ctx,fmpz
from fractions import Fraction
from pathlib import Path
import json,math
rs=json.loads(Path('L18_small.json').read_text());fp=[int(z)%5 for z in rs['coefficients_ascending']]
K=fq_default_ctx(modulus=fmpz_mod_poly_ctx(5)(fp))
rp=json.loads(Path('X017_point_small_field.json').read_text())
def red(cs):
 a=[Fraction(z) for z in cs];assert all(z.denominator%5 for z in a)
 return K([z.numerator*pow(z.denominator,-1,5)%5 for z in a])
P=(red(rp['point_x_coefficients_ascending']),red(rp['point_y_coefficients_ascending']));T=(K(7),K(13))

def valid(P):
 if P is None:return True
 x,y=P;return y*y+x*y+y==x*x*x-x*x-x-14

def add(P,Q):
 if P is None:return Q
 if Q is None:return P
 x,y=P;xx,yy=Q
 if x==xx:
  if (y+yy+x+1).is_zero():return None
  assert y==yy
  lam=(3*x*x-2*x-1-y)/(2*y+x+1)
 else:lam=(yy-y)/(xx-x)
 nu=y-lam*x
 u=lam*lam+lam+1-x-xx;v=-(lam+1)*u-nu-1
 return u,v

def neg(P):
 if P is None:return None
 return P[0],-P[1]-P[0]-1

def mul(P,n):
 if n<0:return mul(neg(P),-n)
 out=None
 while n:
  if n&1:out=add(out,P)
  P=add(P,P);n>>=1
 return out

def key(P):
 if P is None:return None
 return tuple(map(int,P[0].to_list())),tuple(map(int,P[1].to_list()))

def serial(P):
 if P is None:return None
 return [list(map(int,P[0].to_list())),list(map(int,P[1].to_list()))]

assert valid(P) and valid(T)
a,b=2,-2
for n in range(2,19):a,b=b,-2*b-5*a
N=5**18+1-b;facts=[(int(l),int(e)) for l,e in fmpz(N).factor()]
assert mul(P,N) is None
m=N
for l,e in facts:
 while m%l==0 and mul(P,m//l) is None:m//=l
assert mul(P,m) is None
mfacts=[(int(l),int(e)) for l,e in fmpz(m).factor()]
nonzero=[{'prime':l,'point':serial(mul(P,m//l))} for l,e in mfacts]
assert all(z['point'] is not None for z in nonzero)
print('Group order',N,'factor',facts,flush=True)
print('Point order',m,'factor',mfacts,flush=True)
print('Point coefficient key',key(P),flush=True)

# BSGS is used only in subgroups of known small prime-power order.
def bsgs(Q,G,n):
 if Q is None:return 0
 step=math.isqrt(n)+1;baby={};R=None
 for j in range(step):
  baby.setdefault(key(R),j);R=add(R,G)
 stride=neg(mul(G,step));R=Q
 for i in range(step+1):
  j=baby.get(key(R))
  if j is not None:
   ans=i*step+j
   if ans<n and mul(G,ans)==Q:return ans
  R=add(R,stride)
 return None

def crt(vals):
 v=0;mod=1
 for a,n in vals:
  k=(a-v)*pow(mod,-1,n)%n;v+=mod*k;mod*=n
 return v%mod

def dlog(Q):
 if mul(Q,m) is not None:return None
 vals=[]
 for l,e in mfacts:
  n=l**e;co=m//n
  a=bsgs(mul(Q,co),mul(P,co),n)
  if a is None:return None
  vals.append((a,n))
 v=crt(vals)
 if mul(P,v)!=Q:return None
 return v

Tor=[mul(T,k) for k in range(4)]
tlog=dlog(T);ttlog=dlog(mul(T,2))
Hsize=m if tlog is not None else (2*m if ttlog is not None else 4*m)
print('T discrete log',tlog,'2T discrete log',ttlog,'generated subgroup size',Hsize,flush=True)
jdata=json.loads(Path('X017_jmap_and_fibre.json').read_text())
Aj=jdata['A_coefficients_descending'];Bj=jdata['B_coefficients_descending']
def eval_desc(cs,z):
 r=K(0)
 for v in cs:r=r*z+v
 return r
def jval(Q):
 assert Q is not None and Q[0]!=K(7)
 xx,yy=Q
 return (eval_desc(Aj,xx)+eval_desc(Bj,xx)*yy)/(xx-7)**17
assert jval(P)==K(2)
conj=[];Q=P
for i in range(18):
 assert valid(Q) and jval(Q)==K(2)
 vals=[]
 for k in range(4):
  n=dlog(add(Q,neg(Tor[k])))
  if n is not None:vals.append({'torsion_multiple':k,'n_mod_orderP':n})
 conj.append({'frobenius_power':i,'point':serial(Q),'representations':vals})
 print('Frob',i,vals,flush=True)
 Q=Q[0].frobenius(),Q[1].frobenius()
assert Q==P and len({str(z['point']) for z in conj})==18
out={'modulus_ascending':fp,'field_order':5**18,'curve':[1,-1,1,-1,-14],
 'group_order':N,'group_order_factors':facts,'trace_frobenius18':b,
 'point':serial(P),'torsion_point':serial(T),'point_order':m,'point_order_factors':mfacts,
 'order_nonzero_witnesses':nonzero,'T_discrete_log':tlog,'twoT_discrete_log':ttlog,
 'subgroup_generated_by_P_T_order':Hsize,'j_mod5':2,'frobenius_conjugates':conj,
 'scope':'Only finite-field statements. No global rank, index, Chabauty completeness, or solution exclusion is asserted.'}
Path('L18_finite_group5_certificate.json').write_text(json.dumps(out,indent=2)+'\n')
print('Exact finite-field certificate written.',flush=True)
