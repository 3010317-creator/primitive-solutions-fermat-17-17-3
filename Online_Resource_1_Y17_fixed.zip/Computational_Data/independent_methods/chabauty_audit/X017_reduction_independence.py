"""Prove point independence using joint images in A(F_q)/2A(F_q).
All arithmetic is integer/rational and finite. No height approximation.
"""
from pathlib import Path
from fractions import Fraction
from math import isqrt
import json
F=json.loads(Path('L18_small.json').read_text())['coefficients_ascending']
records=[json.loads(Path(p).read_text()) for p in ['X017_point_small_field.json','X017_P2_small_field.json','X017_P3_small_field.json']]
xy=[[[Fraction(c) for c in r[k]] for k in ['point_x_coefficients_ascending','point_y_coefficients_ascending']] for r in records]

def ev(c,t,p):
 a=0
 for b in reversed(c):a=(a*t+b)%p
 return a

def add(P,Q,p):
 if P is None:return Q
 if Q is None:return P
 x,y=P;xx,yy=Q
 if x==xx:
  if (y+yy+x+1)%p==0:return None
  assert y==yy
  lam=(3*x*x-2*x-1-y)*pow((2*y+x+1)%p,-1,p)%p
 else:lam=(yy-y)*pow((xx-x)%p,-1,p)%p
 nu=(y-lam*x)%p
 u=(lam*lam+lam+1-x-xx)%p;v=(-(lam+1)*u-nu-1)%p
 return u,v

def points(p):
 squares={}
 for v in range(p):squares.setdefault(v*v%p,[]).append(v)
 out=[None];inv2=pow(2,-1,p)
 for x in range(p):
  d=((x+1)**2+4*(x**3-x*x-x-14))%p
  out.extend((x,(-x-1+v)*inv2%p) for v in squares.get(d,[]))
 return out

def valid(P,p):
 if P is None:return True
 x,y=P;return (y*y+x*y+y-x*x*x+x*x+x+14)%p==0

remaining=set(range(1,16));witnesses=[];tested=[]
for p in range(5,2000):
 if p==17 or any(p%d==0 for d in range(2,isqrt(p)+1)):continue
 if any(c.denominator%p==0 for r in xy for a in r for c in a):continue
 roots=[t for t in range(p) if ev(F,t,p)==0 and ev([i*F[i] for i in range(1,len(F))],t,p)!=0]
 if not roots:continue
 G=points(p);twoG={add(Q,Q,p) for Q in G}
 for t in roots:
  Ps=[tuple(ev([c.numerator*pow(c.denominator,-1,p)%p for c in a],t,p) for a in r) for r in xy]+[(7%p,13%p)]
  assert all(valid(P,p) for P in Ps)
  killed=[]
  for mask in sorted(remaining):
   Q=None
   for i in range(4):
    if mask>>i&1:Q=add(Q,Ps[i],p)
   if Q not in twoG:
    witnesses.append({'mask_P1_P2_P3_T':mask,'prime':p,'field_root':t,'sum_point':Q,'curve_group_order':len(G),'doubling_image_size':len(twoG),'reduced_points':Ps})
    killed.append(mask)
  remaining.difference_update(killed)
  tested.append({'prime':p,'field_root':t,'killed_masks':killed,'remaining_masks':sorted(remaining)})
  if killed:print(tested[-1],flush=True)
  if not remaining:break
 if not remaining:break
out={'scope':'Exact joint finite reduction nondivisibility; coordinate generators P1,P2,P3,T in that order.',
 'nonzero_relations_mod2_remaining':sorted(remaining),'witnesses':witnesses,'tested_prime_points':tested}
if not remaining:
 out['conclusion']='P1,P2,P3,T have independent classes in A(L)/2A(L); since torsion is Z/4, rank A(L)>=3 and P1,P2,P3 are Z-linearly independent modulo torsion.'
else:out['conclusion']='No full independence claim; surviving binary relations need additional analysis.'
Path('X017_reduction_independence_certificate.json').write_text(json.dumps(out,indent=2)+'\n')
print(out['conclusion'],flush=True)
print('remaining',sorted(remaining),flush=True)
