"""General r-dimensional exact mod25 Chabauty preparation (r<=several).
No global Mordell-Weil rank upper bound is asserted.
Run with P2/P3 JSON paths, or omit to use any known default P2/P3 files.
"""
from pathlib import Path
import json,itertools,sys
exec(Path('L18_padic_chabauty_preparation.py').read_text().split('Rings={}')[0])
R=Ring(2);m=rfin['point_order']
paths=sys.argv[1:] or [f for f in ['X017_P2_small_field.json','X017_P3_small_field.json'] if Path(f).exists()]
points=[]
for path in paths:
 data=json.loads(Path(path).read_text())
 xx=R.reduce_rat(list(map(Fraction,data['point_x_coefficients_ascending'])));yy=R.reduce_rat(list(map(Fraction,data['point_y_coefficients_ascending'])))
 uu=4*xx-1;vv=8*yy+4*xx+4
 assert R.pow(vv,2)==R.pow(uu,3)-11*uu-890
 points.append((path,xx,yy,uu,vv))

def coeff(a):return [int(a[i]) for i in range(18)]
def mod5key(x,y):return tuple(int(x[i])%5 for i in range(18)),tuple(int(y[i])%5 for i in range(18))
def fromserial(a):return tuple((list(a[0])+[0]*18)[:18]),tuple((list(a[1])+[0]*18)[:18])
def short_base(n,k):return R.add_torsion(R.multiple(n),k)
def shift(P,z):
 u,v=P
 return u+R.mul(2*v,z),v+R.mul(3*R.pow(u,2)-11,z)
def jpoint(P):
 u,v=P;x=(u+1)*pow(4,-1,25);y=(v-u-5)*pow(8,-1,25)
 return R.mul(R.eval_desc(Ac,x)+R.mul(R.eval_desc(Bc,x),y),R.inv(R.pow(x-7,17)))
def rank5(rows):
 a=[[int(v)%5 for v in row] for row in rows];rank=0
 if not a:return 0
 for col in range(len(a[0])):
  piv=next((i for i in range(rank,len(a)) if a[i][col]),None)
  if piv is None:continue
  a[rank],a[piv]=a[piv],a[rank];iv=pow(a[rank][col],-1,5);a[rank]=[v*iv%5 for v in a[rank]]
  for i in range(len(a)):
   if i!=rank:
    z=a[i][col];a[i]=[(x-z*y)%5 for x,y in zip(a[i],a[rank])]
  rank+=1
  if rank==len(a):break
 return rank

# Formal parameter z=-u/v of [m]P1, using projective division-polynomial values.
pm=R.psi(m)
phi=R.mul(R.u,R.pow(pm,2))-R.mul(R.psi(m-1),R.psi(m+1))
omega=R.mul(R.mul(R.psi(m+2),R.pow(R.psi(m-1),2))-R.mul(R.psi(m-2),R.pow(R.psi(m+1),2)),R.inv4v)
z1=-R.mul(R.mul(phi,pm),R.inv(omega))
assert all(v%5==0 for v in coeff(z1)) and not z1.is_zero()
zlist=[z1];basis=[{'name':'m*P1','formal_parameter_mod25':coeff(z1)}]
# Check formal shift against an independent exact nP calculation.
assert shift(short_base(1,0),z1)==short_base(1+m,0)

for path,xx,yy,uu,vv in points:
 key=mod5key(xx,yy)
 row=next(q for q in rfin['frobenius_conjugates'] if fromserial(q['point'])==key)
 rep=row['representations'][0];n=rep['n_mod_orderP'];k=rep['torsion_multiple'];uq,vq=short_base(n,k)
 # P_i-Q_base: generic Jacobian addition; no division by a nonunit.
 H=uq-uu;dy=-vq-vv
 X=R.pow(dy,2)-R.pow(H,3)-R.mul(2*uu,R.pow(H,2))
 Y=R.mul(dy,R.mul(uu,R.pow(H,2))-X)-R.mul(vv,R.pow(H,3))
 z=-R.mul(R.mul(X,H),R.inv(Y))
 assert all(v%5==0 for v in coeff(z))
 assert shift((uq,vq),z)==(uu,vv)
 zlist.append(z)
 basis.append({'name':path+' - n*P1-k*T','n':n,'k':k,'frobenius_power':row['frobenius_power'],
  'formal_parameter_mod25':coeff(z),'j_mod25':coeff(jpoint((uu,vv)))})

logrows=[[int(z[i])//5%5 for z in zlist] for i in range(18)]
logrank=rank5(logrows);r=len(zlist)
print('Formal logarithm rank mod5:',logrank,'of',r,flush=True)
records=[]
for row in rfin['frobenius_conjugates']:
 rep=row['representations'][0];n=rep['n_mod_orderP'];k=rep['torsion_multiple'];Q=short_base(n,k)
 j0=jpoint(Q);jv=coeff(j0);assert all(v%5==0 for v in jv[1:])
 alpha=[v//5%5 for v in jv[1:]]
 betas=[]
 for z in zlist:
  delta=jpoint(shift(Q,z))-j0
  cv=coeff(delta);assert all(v%5==0 for v in cv)
  betas.append([v//5%5 for v in cv[1:]])
 B=[[betas[j][i] for j in range(r)] for i in range(17)]
 solutions=[]
 for ds in itertools.product(range(5),repeat=r):
  if all((alpha[i]+sum(B[i][j]*ds[j] for j in range(r)))%5==0 for i in range(17)):
   zz=sum((zlist[j]*ds[j] for j in range(r)),R.zero)
   jj=coeff(jpoint(shift(Q,zz)));assert all(v==0 for v in jj[1:])
   solutions.append({'digits':list(ds),'j_constant_mod25':jj[0]})
 rec={'frobenius_power':row['frobenius_power'],'n':n,'k':k,'j_base_coefficients_mod25':jv,
  'alpha':alpha,'derivative_columns':betas,'derivative_rank':rank5(B),'solutions':solutions}
 records.append(rec)
 print('disk',row['frobenius_power'],'derivative_rank',rec['derivative_rank'],'solutions',solutions,flush=True)

out={'prime':5,'modulus':25,'dimension':r,'point_paths':paths,'formal_basis':basis,
'formal_log_matrix_divided_by5':logrows,'formal_log_rank':logrank,'disks':records,
'surviving_disks':[q['frobenius_power'] for q in records if q['solutions']],
'scope':'Exact finite quotient-ring calculations. Global completeness requires a certified rank upper bound and suitable saturation of the full proposed Mordell-Weil subgroup.'}
filename=f'L18_mod25_dimension{r}_certificate.json'
Path(filename).write_text(json.dumps(out,indent=2)+'\n')
print('Written',filename,flush=True)
