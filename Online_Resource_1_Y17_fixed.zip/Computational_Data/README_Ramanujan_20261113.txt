Primitive solutions of a generalized Fermat equation of signature (17, 17, 3)
The Ramanujan Journal
Yuwen Wang
School of Mechanical Engineering, Xi’an Jiaotong University
Xi’an, Shaanxi 710049, P. R. China
Corresponding author: 3010317@proton.me

Online Resource 1 contains the arithmetic data and verification programs supporting the manuscript. Supplementary_Data_Guide.txt gives the file index and execution commands. The original digest manifest records the unchanged original files; MANIFEST_Ramanujan_SHA256.json covers this expanded data selection.
